=== ADMIN 2020 ADMIN THEME ===
Contributors: Mark Ashton
Tags: Admin Theme, Theme, WordPress Admin Theme, Admin UI, User Interface, Admin Page, Admin Panel, WordPress Admin, WordPress Panel, Usability, User Interface
Requires at least: 5.0
Tested up to: 5.4

Admin 2020 transforms your wordpress backend into a whitelabelled, clean and modern dashboard.

== Description ==

Transform Wordpress dashboard into a beautiful, modern experience
A clean and modern Wordpress dashboard theme with a streamlined dashboard, dark mode, extended search and support for other plugins. Proudly powered by UiKit

Get what you want, quicker!
Overhauled menus and integrated search means you can find exactly what you are looking for.

Distraction free interface
Admin 2020s interface is streamlined and distraction free, allowing you to get on with what you do best.

Dark Mode
A dashboard that adapts to your surroundings. Activate dark mode at the click of a button.

Instant Results
A powerful internal search now at your fingertips, what wait for a page to reload to get what you want?

== Installation ==

To do a new installation of the plugin, please follow these steps:

1. Download the 'admin2020.zip' file to your computer.
1. Unzip the file
1. Upload the 'admin2020' folder to the '/wp-content/plugins/' directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.1.7 =
* Fix: Various Bug fixes
* Added: Support following plugins: CF7,Elementor,Google Sitemap,WP Ultimo,Jetpack,Themify Builder
W3 Total Cache,Woocommerce,Wordfence,Yoast SEO,Insert Headers and Footers,Advanced Custom Fields,Fluent Forms, mail poet
* Fix: Fixed problem with disabling admin 2020 styles on admin 2020 specific pages
* Fix: Fixed problem plugin updates showing to non admin users
* Fix: Fixed several problems with multisite
* Added: Admin 2020 is now full translation ready! Will start adding new translations soon. Want to contribute? Email us!

= 1.1.6 =
* Fix: Various Bug fixes
* Added: Ability to change primary link colour
* Added: Added Licensing
* Fix: Fixed bug causing load on front end to crash some websites

= 1.1.5 =
* Fix: Scroll bug on shrunk menu on windows fixed
* Added: Now fully supports WP Multisite
* Added: Added folders to media gallery and media models
* Fix: Fixed privileges for media and dashboard pages
* Added: Updates now show in user menu with notification
* Fix: Bug causing top right user photo not to update to users actual photo
* Fix: Bug causing actions to not display on user table
* Added: Quick copy to image links
* Added: Sub folders for media
* Added: Advanced filters for media

= 1.1.4 =
* Fix: Fixed various CSS issues on mobile views
* Added: Completely New media library added
* Fix: Z index issue on fly out menu
* Fix: Top level menu bug fixed
* Fix: Fixed Default Home Page bug
* Fix: Fixed bug causing comments to display warnings on overview page
* Added: Available updates to the user menu

= 1.1.3 =
* Fix: Fixed various CSS issues and other small bugs
* Added: New dashboard feature including google analytics
* Fix: Page overflow on media page
* Fix: Icon on full screen block editor
* Change: Minified menu is now a flyout menu on hover

= 1.1.2 =
* Fix: Fixed quick edit view
* Fix: Fixed table actions not showing on certain tables
* Change: Changed all checkbox styles
* Change: Changed media gallery view to be horizontal masonary
* Fix: Fixed a few mobile css styles
* Fix: Fixed remember me button on login pages
* Added: Added slight hover animation to certain links

= 1.1.2 =
* Fix: Fixed bug when displaying menu icons in different languages
* Fix: Fixed post layout and product pages for woocommerce
* Change: Added new loading bar to admin bar (option to disable this)

= 1.1.1 =
* Fix: Fixed bug when uploading custom ICON
* Fix: Potential Fatal (extra ',') error when enqueing stylesheet
* Fix: Various other clean ups
* Added: First version of menu visibility options for users installed.

= 1.1.0 =
* Change: Moved project into classes and objects
* Fix: Mobile styles
* Fix: Media Header dark mode
* Fix: Moved JS to .on('click') instead of .click()

= 1.0.4 =
* Fix: Fixed primary button position on mobile
* Fix: Fixed block editor position on mobile

= 1.0.2 =
* Fix: Added support for translations
* Fix: Rewrote JS files
* Fix: Cleaned PHP and CSS
* Fix: Added css table of contents

= 1.0.1 =
* Fix: Added support for multiple plugins

= 1.0 =
* Initial release
