<?php
class Admin_2020_Front{

  private $version;

  public function __construct( $theversion ) {

    $this->version = $theversion;

  }

  public function load(){
    add_action('wp_enqueue_scripts', array($this,'ma_admin_load_front'));
  }

  ///LOAD ADMIN BAR ON FRONT END
  public function ma_admin_load_front() {

      wp_register_style('uikitcss', 'https://cdn.jsdelivr.net/npm/uikit@3.4.2/dist/css/uikit.min.css', array());
      wp_enqueue_style('uikitcss');
      wp_enqueue_script('uikit', 'https://cdn.jsdelivr.net/npm/uikit@3.4.2/dist/js/uikit.min.js', array());
      wp_enqueue_script('uikiticons', 'https://cdn.jsdelivr.net/npm/uikit@3.4.2/dist/js/uikit-icons.min.js', array());

      wp_register_style('ma_admin_head_css', plugin_dir_url(__DIR__) . 'assets/css/ma-admin-head.min.css', array(), $this->version);
      wp_enqueue_style('ma_admin_head_css');

      wp_deregister_style('admin-bar');

  }

}
