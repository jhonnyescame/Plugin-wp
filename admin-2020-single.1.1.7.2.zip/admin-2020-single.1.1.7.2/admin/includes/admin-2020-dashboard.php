<?php
class Admin_2020_Dashboard{

  private $version;

  public function __construct( $theversion ) {

    $this->version = $theversion;

  }

  public function run(){

    add_action( 'admin_menu', array($this,'add_menu_item') );


    if (isset($_GET['page'])) {
        if($_GET['page']=='admin_2020_dashboard'){
          add_action('admin_head', array($this,'add_to_head'),0);
        }
    }

  }

  public function add_menu_item() {

    $slug ='admin_2020_dashboard';
    add_menu_page( '2020 Dashboard', 'Overview', 'read', $slug, array($this,'admin_dashboard_render'),'dashicons-admin2020-grid',0 );
    return;

  }

  public function add_to_head(){

    $options = get_option( 'admin2020_settings' );
    if (isset($options['admin2020_admin2020_google_apikey'])){
      $apikey = $options['admin2020_admin2020_google_apikey'];
    }

    ?>
    <meta name="google-signin-client_id" content="<?php echo $apikey?>">
    <meta name="google-signin-scope" content="https://www.googleapis.com/auth/analytics.readonly">
    <?php
  }

//admin.php?page=myplugin%2Fmyplugin-admin-page.php


	public function admin_dashboard_render() {

    $this->build_grid();

	}

  public function build_grid(){

    $this->googleloader = false;
    $options = get_option( 'admin2020_settings' );
    if (isset($options['admin2020_admin2020_google_apikey']) && isset($options['admin2020_admin2020_google_viewid'])) {
      if ($options['admin2020_admin2020_google_apikey'] != "" && $options['admin2020_admin2020_google_viewid'] != ""){
          $this->googleloader = true;
          $this->adminC1 = $options['admin2020_admin2020_google_apikey'];
        }
    }
		if (isset($options['admin2020_admin2020_google_viewid'])){
      $this->gviewid = $options['admin2020_admin2020_google_viewid'];
		} else {
      $this->gviewid = '';
		}

    $userid = get_current_user_id();
    $user_info = get_userdata($userid);
    $first_name = $user_info->first_name;
    $user = wp_get_current_user();
    $imgurl = esc_url( get_avatar_url( $user->ID ) );
    $greeting = $this->ma_admin_get_welcome();

    /// IF NO NAME SET USE USERNAME
    if (!$first_name) {
        $first_name = $user_info->user_login;
    }





		?>
    <p class="notice" id="gverror" style="display:none;"></p>
    <div uk-grid>
      <div class="uk-width-auto">
          <img class="uk-border-circle" width="60" height="60" src="<?php echo $imgurl?>">
      </div>
      <div class="uk-width-expand">
  			<h2 class="uk-h2 uk-margin-remove "><?php echo $greeting.', '.$first_name?></h2>
        <p class="uk-text-meta uk-margin-remove-top uk-margin-bottom"><?php echo date('jS F Y')?></p>
      </div>

      <?php
      ///ONLY LOAD IF GOOGLE ANALYTICS IS ENABLED
      if($this->googleloader == true){
       ?>
      <div class="uk-position-right uk-padding-large admin2020daterange">
        <div class="uk-inline">
            <span class="uk-form-icon" uk-icon="icon: calendar"></span>
            <input class="uk-input uk-form-small" type="text" style="border-radius:4px;"id="admin2020-date-range"></input>
        </div>

      </div>
      <?php
      } ?>

      <div uk-grid="masonry: true">

      <?php
      $this->total_posts();
      $this->total_pages();
      $this->total_comments();
      $this->recent_comments();
      ///ONLY LOAD IF GOOGLE ANALYTICS IS ENABLED
      if ($this->googleloader == true){
        $this->visitors_chart();
        $this->total_sessions();

        $this->device_breakdown();
        $this->sessions_by_country();
        $this->total_pageviews();
      }
      $this->new_comments();
      $this->most_commented_posts();
      $this->new_users();
      $this->system_info();

      ?>
      </div>
    <?php

  }


  public function total_posts(){

    $posttypes = get_post_types();
    $newPT = array();
    $totalposts = 0;
    foreach($posttypes as $type){
      array_push($newPT,$type);
      $tempcount = wp_count_posts($type);
      $totalposts = $totalposts + $tempcount->publish;
    }
    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
            <span class=""><?php _e('Total Posts','admin2020') ?></span>
          <div class="uk-h3 uk-text-primary uk-margin-remove"> <?php echo number_format($totalposts)?></div>
      </div>
    </div>
    <?php
  }

  public function total_pages(){

    $args = array(
      'numberposts' => -1,
      'post_type'   => 'page'
    );
    $allpages = get_posts( $args );

    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
            <span class=""><?php _e('Total Pages','admin2020') ?></span>
          <div class="uk-h3 uk-text-primary uk-margin-remove"> <?php echo number_format(count($allpages))?></div>
      </div>
    </div>
    <?php
  }

  public function total_comments(){
    $totalcomments = wp_count_comments();
    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
            <span class=""><?php _e('Total Comments','admin2020') ?></span>
          <div class="uk-h3 uk-text-primary uk-margin-remove"> <?php echo number_format($totalcomments->approved)?></div>
      </div>
    </div>
    <?php
  }
  public function recent_comments(){
    $args = array(
        'number'  => '5',
    );
    $comments = get_comments( $args );
    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
        <div class="uk-margin-bottom"><?php _e('Recent Comments','admin2020') ?></div>
          <?php


          if(count($comments)<1){
            ?>
            <p><?php _e('No comments yet','admin2020') ?></p>

            <?php

          } else {

            foreach ( $comments as $comment ){

                $commentdate = human_time_diff( get_comment_date( 'U', $comment->comment_ID ),current_time( 'timestamp' ) );
                $user = get_user_by( 'login', $comment->comment_author );
                $img = get_avatar_url($user->ID);
                $commentlink = get_comment_link($comment);
                ?>

                <div class="uk-grid-small uk-flex-middle " uk-grid>
                    <div class="uk-width-auto" style="width:50px">
                        <img class="uk-border-circle" width="30" height="30" src="<?php echo $img?>">
                    </div>
                    <div class="uk-width-expand">
                        <span class=" uk-margin-remove-bottom"><?php echo $comment->comment_author ?></span>
                        <p class="uk-text-meta uk-margin-remove-top"><?php echo $commentdate?> <?php _e('ago','admin2020') ?></p>
                    </div>
                </div>
                <div class="uk-grid-small uk-margin-bottom" uk-grid>
                    <div class="uk-width-auto" style="width:50px">
                    </div>
                    <div class="uk-width-expand">
                      <a class="" href="<?php echo $commentlink?>">
                        <p class="uk-text-meta uk-margin-remove-bottom"><?php echo substr(esc_html($comment->comment_content),0,50)?>...</p>
                      </a>
                    </div>
                </div>

                <?php
            };
          }
           ?>
      </div>
    </div>
    <?php

  }
  public function visitors_chart(){

    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
        <div class=""><span class="uk-text-meta" uk-icon="icon: google;ratio:0.8"></span> <?php _e('Website Visitors','admin2020') ?></div>
        <div class="uk-text-meta">
          <span class="admin2020circle"></span>
          <span id="total-vists" class="uk-margin-bottom"></span>
        </div>
        <p style="display:none;" class="g-signin2" id="noauthsignin" data-onsuccess="admin2020_reauthorize"></p>
        <span id="admin2020trackingid" style="display:none;"><?php echo $this->gviewid?></span>
        <span id="admin2020Cid" style="display:none;"><?php echo $this->adminC1?></span>
        <canvas id="traffic_visits" style="height:250px;max-height:250px;" class="uk-margin-top"></canvas>
      </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
      admin2020_start_analytics();
    })
    </script>

    <?php
  }

  public function total_sessions(){
    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
        <div class=""><span class="uk-text-meta" uk-icon="icon: google;ratio:0.8"></span>  <?php _e('Total Page Views','admin2020') ?></div>
        <div class="uk-text-meta uk-margin-bottom">
          <span id="totalsessions_text"></span>
        </div>
          <div class="uk-h3 uk-text-primary uk-margin-remove" id="admin2020_total_sessions"></div>

      </div>
    </div>
    <?php
  }

  public function total_pageviews(){
    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
        <div class=""><span class="uk-text-meta" uk-icon="icon: google;ratio:0.8"></span>  <?php _e('Page Views','admin2020') ?></div>
        <div class="uk-text-meta">
          <span class="admin2020circle pageviews"></span>
          <span id="total-sessions"></span>
        </div>
        <canvas id="session_visits" style="height:250px;max-height:250px;" class="uk-margin-top"></canvas>
      </div>
    </div>

    <?php
  }

  public function sessions_by_country(){
    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
        <div class=""><span class="uk-text-meta" uk-icon="icon: google;ratio:0.8"></span> <?php _e('Total Countries','admin2020') ?></div>
        <table class="uk-table uk-table-justify uk-table-small" id="total-sessions-counntry">
          <thead>
            <tr>
              <th>Country</th>
              <th class="uk-text-right">Visits</th>
            </tr>
          </thead>
          <tbody class="uk-text-meta">
          </tbody>

        </table>
      </div>
    </div>

    <?php
  }

  public function device_breakdown(){
    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
        <div class=""><span class="uk-text-meta" uk-icon="icon: google;ratio:0.8"></span>  <?php _e('Device Breakdown','admin2020') ?></div>
        <div class="uk-text-meta">
        </div>
        <canvas id="device_visits" style="height:200px;max-height:200px;" class="uk-margin-top"></canvas>
      </div>
    </div>

    <?php
  }



  public function new_comments(){



    $args = array(
        'orderby'=>'comment_date',
        'order'=>'ASC',
        'date_query' => array(
            'after' => '1 weeks ago',
            'before' => 'tomorrow',
            'inclusive' => true,
        ),
    );
    $thirtyDaysComments = get_comments( $args );

    $commentsByDay = array();
    $datearray = array();
    $commentvalues = array();

    $lastmonth = date('Y-m-d', strtotime('- 6 days'));
    $lastmonthf = date('d/m/y', strtotime($lastmonth));
    array_push($datearray,$lastmonthf);
    $commentsByDay[$lastmonth] = 0;
    for ($k = 1 ; $k < 7; $k++){
      $d = date('Y-m-d', strtotime($lastmonth .'+ '.$k.' days'));
      $fd = date('d/m/y',strtotime($d));
      array_push($datearray,$fd);
      $commentsByDay[$d] = 0;
    }

    foreach ($thirtyDaysComments as $comment){
      $commentid = $comment->comment_ID;
      $date = get_comment_date('Y-m-d',$commentid);
      if(isset($commentsByDay[$date])){
        $commentsByDay[$date] = $commentsByDay[$date] + 1;
      }
    }

    foreach($commentsByDay as $commentcount){
      array_push($commentvalues,$commentcount);
    }
    ?>

    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
        <div class="">Comments</div>
        <?php if (array_sum($thirtyDaysComments)<1){
          ?>
          <p class="uk-text-meta"><?php _e('No new comments in the last 7 days','admin2020') ?></p>
          <?php
        } else {
          ?>
        <div class="uk-text-meta uk-margin-bottom"><span id="total-vists"></span><?php _e('In the last 7 days','admin2020') ?></div>
          <canvas id="commentstracker" style="max-height:250px;"></canvas>
          <script>
          jQuery(document).ready(function($) {
            admin_2020_buildGraphFromPhp(<?php echo json_encode($commentvalues)?>, <?php echo json_encode($datearray) ?>, '29, 209, 161', 'commentstracker', 'Comments');
          })
          </script>
        <?php }
        ?>

      </div>
    </div>

    <?php
  }

  public function most_commented_posts(){


    $posttypes = get_post_types();
    $newPT = array();
    foreach($posttypes as $type){
      array_push($newPT,$type);
    }
    $args = array(
      'numberposts' => 5,
      'post_type'   => $newPT,
      'orderby'     => 'comment_count'
    );

    $mostcommented = get_posts( $args );

    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
        <div class="uk-margin-bottom"><?php _e('Most Commented Posts','admin2020') ?></div>
        <?php
          if (count($mostcommented)>0){
            foreach($mostcommented as $post){
              ?>
              <div class="uk-margin-bottom" style="position:relative;">
                <a class="uk-link uk-link-muted" href="<?php echo get_permalink($post)?>"><?php echo get_the_title($post); ?></a>
                <div class=" uk-badge uk-position-right">
                  <?php echo get_comments_number($post)?>
                </div>
              </div>
              <?php
            }
          } else {
            ?>
            <p><?php _e('No comments yet','admin2020') ?></p>
            <?php
          }
           ?>

      </div>
    </div>
    <?php
  }

  public function new_users(){

    $allusers = count_users();
    $allusers = $allusers['total_users'];

    $args = array (
        'date_query'    => array(
            array(
                'after'     => '2 weeks ago',
                'inclusive' => true,
            ),
         ),
    );

    $user_query = get_users( $args );

    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
        <div class=""><?php _e('New Users','admin2020') ?></div>
        <div class="uk-text-meta uk-margin-bottom"><span id="total-vists"><?php echo count($user_query)?></span> <?php _e('new users in the last 14 days','admin2020') ?></div>
          <div class="uk-h3 uk-text-primary uk-margin-remove" id=""><?php echo $allusers?></div>

      </div>
    </div>
    <?php

  }

  public function system_info(){
    ?>
    <div class="uk-width-1-3@m uk-width-1-1@s">
      <div class="uk-card uk-card-default uk-card-body">
        <div class="uk-margin-bottom"><?php _e('System Info','admin2020') ?></div>
          <div class="uk-grid uk-text-meta">
            <div class="uk-width-2-3">
              WordPress Version:
            </div>
            <div class="uk-width-1-3">
              <?php echo get_bloginfo( 'version' );?>
            </div>
            <div class="uk-width-2-3">
              PHP Version:
            </div>
            <div class="uk-width-1-3">
              <?php echo phpversion();?>
            </div>
            <div class="uk-width-2-3">
              Admin 2020 Version:
            </div>
            <div class="uk-width-1-3">
              <?php echo $this->version;?>
            </div>
          </div>

      </div>
    </div>
    <?php
  }



  public function ma_admin_get_welcome(){
    $time = date("H");
    $timezone = date("e");
    if ($time < "12") {
        $greeting = "Good morning";
    } else
    if ($time >= "12" && $time < "17") {
        $greeting = "Good afternoon";
    } else
    if ($time >= "17") {
        $greeting = "Good evening";
    }
    return $greeting;
  }

}
