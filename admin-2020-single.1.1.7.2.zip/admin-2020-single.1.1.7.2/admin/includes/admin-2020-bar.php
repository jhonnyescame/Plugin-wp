<?php
class Admin_2020_Admin_Bar{


  public function build(){

    global $pagenow;
    if($pagenow == "update.php"){
      return;
    }



    add_action('admin_head', array( $this, 'render_gutenberg_logo' ),0);
    add_action('admin_head', array( $this, 'admin_2020_bar_rebuild' ));

  }

  public function buildpublic(){

    add_action('wp_head', array( $this, 'admin_2020_bar_rebuild' ));

  }

  public function render_gutenberg_logo(){

    $logo = $this->ma_admin_get_logo();
    ?>
    <style>
    .edit-post-fullscreen-mode-close{
      background-image: url('<?php echo $logo?>') !important;
    }
    .edit-post-fullscreen-mode-close.has-icon:hover{
      background-image: url('<?php echo $logo?>') !important;
    }

    </style>
    <?php
  }
///REBUILD ADMIN MENU AND BAR
  public function admin_2020_bar_rebuild() {

      if (!is_admin_bar_showing()){
        return;
      }

      //print_r(get_plugins());

      global $wp_admin_bar;
      ///GET USER DETAILS
      $current_user = wp_get_current_user();
      $userid = get_current_user_id();
      $user_info = get_userdata($userid);
      $first_name = $user_info->first_name;

      $adminurl = get_admin_url();
      $homeurl = $adminurl;

      $options = get_option( 'admin2020_settings' );
      if (isset($options['admin2020_overiew_homepage'])){
        if (isset($options['admin2020_disable_overview'])){
            //OVERVIEW IS DISABLED
        } else {
          $homeurl = $adminurl.'admin.php?page=admin_2020_dashboard';
        }
      }

      ///GET POST TYPES AND CATEGORIES FOR SEARCH
      $args = array('public' => true,);
      $posttypes = get_post_types($args);
      $categories = get_categories();

      if (is_super_admin()){
        ////GET UPDATES
        $pluginupdates = get_plugin_updates();
        $themeupdates = get_theme_updates();
        $wordpressupdates = get_core_updates();

        if(isset($wordpressupdates[0])){
          $wpversion =  $wordpressupdates[0]->version;
          global $wp_version;

          if ($wpversion > $wp_version){
            $wordpressupdates = 1;
          } else {
            $wordpressupdates = 0;
          }
        } else {
          $wordpressupdates = 0;
        }

        $totalupdates = count($pluginupdates) + count($themeupdates) + $wordpressupdates;

      }

      /// IF NO NAME SET USE USERNAME
      if (!$first_name) {
          $first_name = $user_info->user_login;
      }

      /// GET WELCOME GREETING
      $greeting = $this->ma_admin_get_welcome();


      /// GET ADMIN LOGO
      $logo = $this->ma_admin_get_logo();

      /// START MENU BUILD
      ob_start();
  ?>
    <!-- BUILD ADMIN BAR -->
  	<div uk-sticky="sel-target: .ma-admin-bar;" id="wpadminbar">
  	<nav class="uk-navbar-container uk-navbar-transparent uk-background-default ma-admin-bar uk-padding uk-padding-remove-vertical" id="wp-toolbar" uk-navbar>

  	    <div class="uk-navbar-left">
  	        <ul class="uk-navbar-nav">
  	            <li class="uk-active uk-visible@m">
  	            <a href="<?php echo $homeurl ?>" class="uk-padding-remove-horizontal ma-admin-site-logo"><img alt="Site Logo" src="<?php echo $logo ?>"></a>
  	            </li>

                <li class="uk-hidden@m">
                  <a href="#" uk-icon="icon: list" class="uk-padding-remove-horizontal" uk-toggle="target: #adminmenumain; animation: uk-animation-slide-top;cls: ma-admin-menu-visible" ></a>
                </li>
  	        </ul>
  	    </div>

  	    <div class="uk-navbar-right">

  	        <ul class="uk-navbar-nav">
  		        <div>
  		            <a class="uk-navbar-toggle" uk-search-icon href="#" uk-toggle="target: .ma-admin-search-results; animation: uk-animation-slide-top"></a>
  		        </div>

              <li><a href="#" id="maAdminToggleScreenOptions"><span class="" uk-icon="icon: cog"></span></a></li>

              <?php
              if (is_multisite() && current_user_can('administrator') && is_admin()){
               ?>
              <li>
                <?php
                $sites = get_sites();
                ?>
                <a><span uk-icon="icon:home"></span></a>
                <div uk-dropdown>
                    <ul class="uk-nav uk-nav-default uk-nav-parent-icon" uk-nav>
                        <li class=""><a href="<?php echo network_admin_url()?>"><span uk-icon="icon:server"></span> Network Admin</a></li>
                        <li class="uk-nav-divider"></li>
                        <li class=""><a href="#"><span uk-icon="icon:wordpress"></span> Sites</a></li>
                        <?php
                        foreach($sites as $site){
                          $subsite_id = get_object_vars($site)["blog_id"];
                          $subsite_name = get_blog_details($subsite_id)->blogname;
                          ?>
                          <li class="uk-parent"><a href="#"><?php echo $subsite_name?></a>
                            <ul class="uk-nav-sub" >
                                <li><a href="<?php echo get_admin_url($subsite_id)?>"><?php _e('Dashboard','admin2020') ?></a></li>
                                <li><a href="<?php echo get_site_url($subsite_id)?>"><?php _e('Visit Site','admin2020') ?></a></li>
                            </ul>
                          </li>
                          <?php
                        }
                         ?>
                    </ul>
                </div>
              </li>
            <?php } ?>

	            <li class="uk-active" uk-toggle="target: #offcanvas-user-menu" style="position:relative">
  	            <a href="#" class="ma-admin-profile-img">
                  <div style="position:relative;">
                    <img src="<?php echo get_avatar_url($userid); ?>">
                    <?php
                    if (is_super_admin()){
                        if ($totalupdates > 0){?>
                        <span class="uk-badge uk-position-top-right-out admin2020notificationBadge" style="left: 17px;top: -5px;background:#f0506e;color:#fff"><?php echo $totalupdates?></span>
                      <?php }
                    }?>
                  </div>
                </a>
	            </li>

  	        </ul>

  	    </div>

  	</nav>
    <?php

    $options = get_option( 'admin2020_settings' );
		if (!isset($options['admin2020_admin2020_loader'])){

      ?>
      <div class="admin2020loaderwrap" id="admin2020siteloader">
        <div class="admin2020loader"></div>
      </div>
      <?php

    }
    ?>

  	</div>
    <!-- END OF ADMIN BAR -->

    <!-- BUILD SEARCH DROP -->
  	<div class="uk-padding-large uk-background-default ma-admin-search-results" aria-hidden="true" hidden>

  		<div class="uk-padding uk-position-top-right">
  		<button class="uk-close-large" type="button" uk-close uk-toggle="target: .ma-admin-search-results; animation: uk-animation-slide-bottom"></button>
  		</div>

  		<div class="uk-grid uk-grid-large">

  			<div class="uk-width-1-3@m uk-width-1-1@s">

  				<div class="uk-margin uk-grid-small uk-child-width-1-1 uk-grid" id="ma-admin-search-filters">
  					<h4 class="uk-margin"><span class="uk-margin-small-right" uk-icon="icon: search"></span><?php _e('Search:','admin2020')?></h4>
  					<div class="uk-margin-bottom">
  					    <form class="uk-search uk-search-default uk-width-1-1">
  					        <span uk-search-icon></span>
  					        <input class="uk-search-input" type="search" placeholder="<?php _e('Search...','admin2020')?>" id="ma-admin-search" autofocus>
  					    </form>
  					</div>

  			         <h4 class="uk-margin-bottom"><span class="uk-margin-small-right" uk-icon="icon: settings"></span><?php _e('Filters:','admin2020')?></h4>

  			         <ul class="uk-list">
  				         <li class="uk-list-title">Post Types</li>


  			         <?php foreach ($posttypes as $posttype) {
          $uppercase = ucfirst($posttype);
  ?>

  				         <li><label><input class="ma-admin-filter ma-admin-post-types" type="checkbox" id="" checked="" ma-admin-filter="<?php echo $posttype ?>"> <?php echo $uppercase ?></label></li>

  				         <?php
      }
  ?>
  			         </ul>

  			         <ul class="uk-list">
  				         <li class="uk-list-title uk-margin-top"><?php _e('Categories:','admin2020')?></li>


  			         <?php foreach ($categories as $cats) {
          $uppercase = ucfirst($cats->name);
  ?>

  				         <li><label><input class="ma-admin-filter ma-admin-categories" type="checkbox" id="" ma-admin-filter="<?php echo $cats->term_id ?>"> <?php echo $uppercase ?></label></li>

  				         <?php
      }
  ?>
  			         </ul>

  			         <div><button class="uk-button uk-button-default uk-margin-large-top ma-admin-apply-filters"><?php _e( 'Apply Filters','admin2020')?></button></div>
  				</div>

  			</div>

  			<div class="uk-width-2-3@m uk-width-1-1@s">
  				<div class="uk-text-meta" id="searchcount"></div>
  				<div id="admin_search_results"></div>
  			</div>

  		</div>

  	</div>
    <!-- END OF SEARCH DROP -->





    <!-- OFFCANVAS USER MENU -->
  	<div id="offcanvas-user-menu" uk-offcanvas="flip: true; overlay: true;">
  	    <div class="uk-offcanvas-bar">

  	        <button class="uk-offcanvas-close" type="button" uk-close></button>

  	        <h3 class="uk-margin-remove-top"><?=sprintf(__( '%s, %s', 'admin-2020' ), $greeting, $first_name)?></h3>


  	        <ul class="uk-nav uk-nav-default">


  				<li><a href="<?php echo get_site_url() ?>"><span class="uk-margin-right" uk-icon="icon: link"></span><?php _e('View Website','admin2020')?></a></li>
  		        <li class="uk-nav-divider ma-admin-smaller-divider"></li>
  		        <li><a href="<?php echo get_edit_profile_url($userid) ?>"><span class="uk-margin-right" uk-icon="icon: user"></span><?php _e('View Profile','admin2020')?></a></li>
  		        <li><a href="<?php echo get_edit_profile_url($userid) ?>"><span class="uk-margin-right" uk-icon="icon: settings"></span><?php _e('Edit Profile','admin2020')?></a></li>

  		        <li><a href="#" id="maAdminSwitchDarkMode"><span class="uk-margin-right" uk-icon="icon: cog"></span><?php _e('Toggle Dark Mode','admin2020')?></a></li>

              <?php
              if (is_super_admin()){
                   if ($totalupdates > 0){?>
                  <li class="uk-nav-divider ma-admin-smaller-divider"></li>
                  <li>
                    <a href="<?php echo $adminurl.'update-core.php'?>" id="" style="position:relative;">
                      <span class="uk-margin-right" uk-icon="icon: refresh"></span><?php _e('All Updates','admin2020')?>
                      <span class="uk-badge uk-position-center-right uk-text-primary" style="background:#f0506e"><?php echo $totalupdates?></span>
                    </a>
                  </li>

                  <?php if ($wordpressupdates > 0){?>
                  <li>
                    <a href="<?php echo $adminurl.'update-core.php'?>" id="" style="position:relative;">
                      <span class="uk-margin-right" uk-icon="icon: wordpress"></span><?php _e('WordPress','admin2020')?>
                      <span class="uk-badge uk-position-center-right uk-text-primary" style="background:#f0506e"><?php echo $wordpressupdates?></span>
                    </a>
                  </li>
                  <?php } ?>

                  <?php if (count($pluginupdates) > 0){?>
                  <li>
                    <a href="<?php echo $adminurl.'plugins.php'?>" id="" style="position:relative;">
                      <span class="uk-margin-right" uk-icon="icon: bolt"></span><?php _e('Plugins','admin2020')?>
                      <span class="uk-badge uk-position-center-right uk-text-primary" style="background:#f0506e"><?php echo count($pluginupdates)?></span>
                    </a>
                  </li>
                <?php } ?>

                  <?php if (count($themeupdates) > 0){?>
                  <li>
                    <a href="<?php echo $adminurl.'themes.php'?>" id="" style="position:relative;">
                      <span class="uk-margin-right" uk-icon="icon: paint-bucket"></span><?php _e('Themes','admin2020')?>
                      <span class="uk-badge uk-position-center-right uk-text-primary" style="background:#f0506e"><?php echo count($themeupdates)?></span>
                    </a>
                  </li>
                <?php }
              }?>

            <?php }?>

  		        <li class="uk-nav-divider ma-admin-smaller-divider"></li>
  		        <li><a href="<?php echo wp_logout_url() ?>"><span class="uk-margin-right" uk-icon="icon: sign-out"></span><?php _e('Logout','admin2020')?></a></li>
  		    </ul>

  	    </div>
  	</div>
    <!-- END OF OFFCANVAS USER MENU -->

    <!-- ECHO ADMIN MENU -->
  	<?php
      $wp_admin_bar = ob_get_clean();
      echo $wp_admin_bar;
  }


  public function ma_admin_get_welcome(){
    $time = date("H");
    $timezone = date("e");
    if ($time < "12") {
        $greeting = "Good morning";
    } else
    if ($time >= "12" && $time < "17") {
        $greeting = "Good afternoon";
    } else
    if ($time >= "17") {
        $greeting = "Good evening";
    }
    return $greeting;
  }

  public function ma_admin_get_logo(){
    $options = get_option('admin2020_settings');
    if (isset($options['admin2020_image_field_0'])){
      $logo = $options['admin2020_image_field_0'];
    } else {
      $logo = esc_url(plugins_url('/assets/img/LOGO-BLUE.png', __DIR__));
    }
    if (!$logo) {
        $logo = esc_url(plugins_url('/assets/img/LOGO-BLUE.png', __DIR__));
    }
    return $logo;
  }

}
