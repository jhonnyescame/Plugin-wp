<?php
class Admin_2020_Media{

  private $version;

  public function __construct( $theversion ) {

    $this->version = $theversion;

  }

  public function run(){

    add_action( 'admin_menu', array($this,'add_menu_item') );
    add_action( 'admin_menu', array($this,'add_menu_item') );
    add_action( 'init', array($this,'admin2020_create_folders_cpt') );
    ///AJAX
    add_action('wp_ajax_admin2020_get_media_later', array($this,'admin2020_get_media_later'));
    add_action('wp_ajax_admin2020_save_attachment', array($this,'admin2020_save_attachment'));
    add_action('wp_ajax_admin2020_delete_attachment', array($this,'admin2020_delete_attachment'));
    add_action('wp_ajax_admin2020_delete_multiple_attachment', array($this,'admin2020_delete_multiple_attachment'));
    add_action('wp_ajax_admin2020_upload_attachment', array($this,'admin2020_upload_attachment'));
    add_action('wp_ajax_admin2020_get_media', array($this,'admin2020_get_media'));
    ///FOLDER AJAX
    add_action('wp_ajax_admin2020_create_folder', array($this,'admin2020_create_folder'));
    add_action('wp_ajax_admin2020_create_sub_folder', array($this,'admin2020_create_sub_folder'));
    add_action('wp_ajax_admin2020_delete_folder', array($this,'admin2020_delete_folder'));
    add_action('wp_ajax_admin2020_rename_folder', array($this,'admin2020_rename_folder'));
    add_action('wp_ajax_admin2020_move_to_folder', array($this,'admin2020_move_to_folder'));
    ///PULL FOLDERS TO MEDIA MODAL
    add_filter( 'wp_prepare_attachment_for_js', array($this,'admin2020_pull_meta_to_attachments'), 10, 3 );
    add_action( 'wp_enqueue_media', array($this,'admin2020_add_media_overrides') );


  }

  public function admin2020_add_media_overrides() {
      add_action( 'admin_footer', array($this,'override_media_templates') );
      wp_enqueue_script('ma-admin-media', plugin_dir_url(__DIR__) . 'assets/js/ma-admin-media.min.js', array('jquery'), $this->version);
      wp_localize_script('ma-admin-media', 'ma_admin_media_ajax', array('ajax_url' => admin_url('admin-ajax.php'), 'security' => wp_create_nonce('ma-admin-media-security-nonce')));
      wp_register_style('ma-admin-media_css', plugin_dir_url(__DIR__) . 'assets/css/ma-admin-media.min.css', array(), $this->version);
      wp_enqueue_style('ma-admin-media_css');
  }

  public function admin2020_pull_meta_to_attachments(  $response, $attachment, $meta ) {
      $mimetype = get_post_mime_type($attachment->ID);
      $pieces = explode("/", $mimetype);
      $type = $pieces[0];
      $folderid = get_post_meta( $attachment->ID, 'admin2020_folder', true );
      $response[ 'folderid' ] = $folderid." filter-".$type;
      return $response;
  }

  public function admin2020_create_folders_cpt(){

     $labels = array(
      'name'               => _x( 'Folder', 'post type general name', 'admin2020' ),
      'singular_name'      => _x( 'folder', 'post type singular name', 'admin2020' ),
      'menu_name'          => _x( 'Folders', 'admin menu', 'admin2020' ),
      'name_admin_bar'     => _x( 'Folder', 'add new on admin bar', 'admin2020' ),
      'add_new'            => _x( 'Add New', 'folder', 'admin2020' ),
      'add_new_item'       => __( 'Add New Folder', 'admin2020' ),
      'new_item'           => __( 'New Folder', 'admin2020' ),
      'edit_item'          => __( 'Edit Folder', 'admin2020' ),
      'view_item'          => __( 'View Folder', 'admin2020' ),
      'all_items'          => __( 'All Folders', 'admin2020' ),
      'search_items'       => __( 'Search Folders', 'admin2020' ),
      'not_found'          => __( 'No Folders found.', 'admin2020' ),
      'not_found_in_trash' => __( 'No Folders found in Trash.', 'admin2020' )
    );
     $args = array(
      'labels'             => $labels,
      'description'        => __( 'Description.', 'Add New Folder' ),
      'public'             => false,
      'publicly_queryable' => false,
      'show_ui'            => false,
      'show_in_menu'       => false,
      'query_var'          => false,
      'has_archive'        => false,
      'hierarchical'       => false,
    );
    register_post_type( 'admin2020folders', $args );
 }

  public function add_menu_item() {

    $slug ='admin_2020_media';
    add_menu_page( 'Media Library', 'Media', 'read', $slug, array($this,'admin_media_render'),'dashicons-admin2020-media',9 );
    return;

  }

  public function admin2020_get_media() {
      if (defined('DOING_AJAX') && DOING_AJAX && check_ajax_referer('ma-admin-security-nonce', 'security') > 0) {

          echo $this->build_media(0,0);

      }
      die();
  }

  public function admin2020_upload_attachment() {
      if (defined('DOING_AJAX') && DOING_AJAX && check_ajax_referer('ma-admin-security-nonce', 'security') > 0) {

        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );

        $folderid = $_POST['folderid'];

          foreach ($_FILES as $file){

            $uploadedfile = $file;
            $upload_overrides = array(
              'test_form' => false
            );


            $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
            $movefile;
            ////ADD Attachment

            $wp_upload_dir = wp_upload_dir();
            $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $uploadedfile['name']);

            	$attachment = array(
            		"guid" => $movefile['url'],
            		"post_mime_type" => $movefile['type'],
            		"post_title" => $withoutExt,
            		"post_content" => "",
            		"post_status" => "published",
            		"post_author" => 1
            	);

            	$id = wp_insert_attachment( $attachment, $movefile['file'],0);

            	$attach_data = wp_generate_attachment_metadata( $id, $movefile['file'] );
            	wp_update_attachment_metadata( $id, $attach_data );
              update_post_meta($id, "admin2020_folder",$folderid);

            ////END ATTACHMENT


          }
          //echo $this->build_media();
          echo json_encode($movefile);
           //echo '<pre>' . print_r( $_FILES, true ) . '</pre>';
      }
      die();
  }


  public function admin2020_delete_multiple_attachment() {
      if (defined('DOING_AJAX') && DOING_AJAX && check_ajax_referer('ma-admin-security-nonce', 'security') > 0) {

          $attachmentids = $_POST['theids'];

          foreach ($attachmentids as $attachmentid){

            wp_delete_attachment($attachmentid);

          }

          echo $this->build_media(0,0);
      }
      die();
  }

  public function admin2020_move_to_folder() {
      if (defined('DOING_AJAX') && DOING_AJAX && check_ajax_referer('ma-admin-security-nonce', 'security') > 0) {

          $attachmentids = $_POST['theids'];
          $folderid = $_POST['folderid'];

          foreach ($attachmentids as $attachmentid){

            //wp_delete_attachment($attachmentid);
            update_post_meta($attachmentid, "admin2020_folder",$folderid);

          }

          echo $this->build_media(0,0);
      }
      die();
  }

  public function admin2020_delete_attachment() {
      if (defined('DOING_AJAX') && DOING_AJAX && check_ajax_referer('ma-admin-security-nonce', 'security') > 0) {

          $attachmentid = $_POST['imgid'];

          wp_delete_attachment($attachmentid);
          echo $this->build_media(0,0);

      }
      die();
  }

  public function admin2020_create_folder() {
      if (defined('DOING_AJAX') && DOING_AJAX && check_ajax_referer('ma-admin-media-security-nonce', 'security') > 0) {

          $foldername = wp_strip_all_tags($_POST['title']);
          $activeid = wp_strip_all_tags($_POST['activeid']);

          $my_post = array(
              'post_title'    => $foldername,
              'post_status'   => 'publish',
              'post_type'     => 'admin2020folders'
          );

          // Insert the post into the database.
          wp_insert_post( $my_post );

          echo $this->get_folders($activeid);

      }
      die();
  }

  public function admin2020_create_sub_folder() {
      if (defined('DOING_AJAX') && DOING_AJAX && check_ajax_referer('ma-admin-media-security-nonce', 'security') > 0) {

          $folderid = wp_strip_all_tags($_POST['parentid']);
          $activeid = wp_strip_all_tags($_POST['activeid']);

          $my_post = array(
              'post_title'    => 'Untitled Folder',
              'post_status'   => 'publish',
              'post_type'     => 'admin2020folders'
          );

          // Insert the post into the database.
          $thefolder = wp_insert_post( $my_post );
          update_post_meta($thefolder,"parent_folder",$folderid);

          echo $this->get_folders($activeid);

      }
      die();
  }

  public function admin2020_rename_folder() {
      if (defined('DOING_AJAX') && DOING_AJAX && check_ajax_referer('ma-admin-media-security-nonce', 'security') > 0) {

          $foldername = $_POST['title'];
          $folderid = $_POST['folderid'];
          $activeid = $_POST['activeid'];

          $my_post = array(
              'post_title'    => $foldername,
              'post_status'   => 'publish',
              'ID'            => $folderid,
          );

          // Insert the post into the database.
          wp_update_post( $my_post );

          echo $this->get_folders($activeid);

      }
      die();
  }

  public function admin2020_delete_folder() {
      if (defined('DOING_AJAX') && DOING_AJAX && check_ajax_referer('ma-admin-media-security-nonce', 'security') > 0) {

          $folderid = $_POST['folderid'];
          $activeid = $_POST['activeid'];

          wp_delete_post($folderid);

          echo $this->get_folders($activeid);

      }
      die();
  }

  public function get_folders($activeid){

    $args = array(
      'numberposts' => -1,
      'post_type'   => 'admin2020folders',
      'orderby' => 'title',
      'order'   => 'ASC',
    );

    $folders = get_posts( $args );

    if (count($folders) < 1){
      ?>
      <p class="uk-text-meta"><?php _e('No folders yet, why not create one?','admin2020') ?></p>
      <?php
      return;
    }

    foreach ($folders as $folder){

      $parent_folder = get_post_meta($folder->ID, "parent_folder",true);
      $activeclass = "";
      if($activeid == $folder->ID){
        $activeclass = "uk-active";
      }
      if (!$parent_folder){
      ?>

      <div class="admin2020folder" uk-toggle="target: #subfolder<?php echo $folder->ID?>" folder-id="<?php echo $folder->ID?>" ondrop="admin2020mediadrop(event)" ondragover="admin2020mediaAllowDrop(event)" ondragleave="admin2020mediaDropOut(event)">
        <a href="#" uk-filter-control="filter: [admin2020_folders='<?php echo $folder->ID?>'];group: folders" class="admin2020folderTitle uk-link-muted <?php echo $activeclass?>"><span class="uk-margin-small-right" uk-icon="icon: folder"></span><?php echo $folder->post_title ?></a>
        <div class="" style="float:right">
          <span uk-icon="icon:cog" class="folderoptions uk-margin-right"></span>
           <div class="uk-padding-small" uk-dropdown="mode: click; pos: bottom-right" style="width:auto">
             <ul class="uk-nav uk-dropdown-nav">
               <li class="uk-margin-small-bottom">
                 <input class="uk-input uk-form-small" id="<?php echo $folder->ID?>changefoldername" value="<?php echo $folder->post_title ?>">
               </li>
               <li class="uk-margin-small-bottom">
                 <button class="uk-button uk-button-primary uk-button-small uk-width-1-1" onclick="admin2020renamefolder(<?php echo $folder->ID?>);"><?php _e('Update','admin2020') ?></button>
               </li>
               <li class="uk-margin-small-bottom">
                 <button class="uk-button uk-button-default uk-button-small uk-width-1-1" onclick="admin2020createSubfolder(<?php echo $folder->ID?>);"><?php _e('New Subfolder','admin2020') ?></button>
               </li>
               <li class="uk-nav-divider"></li>
               <li>
                 <button class="uk-button uk-button-danger uk-button-small uk-width-1-1" onclick="admin2020deletefolder(<?php echo $folder->ID?>);"><?php _e('Delete','admin2020') ?></button>
               </li>
             </ul>
           </div>
          <span class="uk-badge admin2020folderCount">0</span>
        </div>
      </div>



      <?php

      $counter = 0;
      foreach ($folders as $subfolder){

        $currentfolder = $folder->ID;
        $parentfolder = get_post_meta($subfolder->ID, "parent_folder",true);

        $activeclass = "";
        $hider = 'hidden';

        if($activeid == $subfolder->ID){
          $activeclass = "uk-active";
        }

        foreach ($folders as $quickcheck){
          if($activeid == $quickcheck->ID && get_post_meta($quickcheck->ID, "parent_folder",true) == $currentfolder){
            $hider = 'aria-hidden="false"';
          }
        }

        if ($counter == 0){
          ?>
          <div id="subfolder<?php echo $folder->ID?>" class="admin2020subFolderWrap" <?php echo $hider?>>
          <?php
        }
        $counter = $counter + 1;

        if ($parentfolder == $currentfolder){




          ?>
          <div class="admin2020folder subfolder" folder-id="<?php echo $subfolder->ID?>" ondrop="admin2020mediadrop(event)" ondragover="admin2020mediaAllowDrop(event)" ondragleave="admin2020mediaDropOut(event)">
            <a href="#" uk-filter-control="filter: [admin2020_folders='<?php echo $subfolder->ID?>'];group: folders" class="admin2020folderTitle uk-link-muted <?php echo $activeclass?>"><span class="uk-margin-small-right" uk-icon="icon: folder"></span><?php echo $subfolder->post_title ?></a>
            <div class="" style="float:right">
              <span uk-icon="icon:cog" class="folderoptions uk-margin-right"></span>
               <div class="uk-padding-small" uk-dropdown="mode: click; pos: bottom-right" style="width:auto">
                 <ul class="uk-nav uk-dropdown-nav">
                   <li class="uk-margin-small-bottom">
                     <input class="uk-input uk-form-small" id="<?php echo $subfolder->ID?>changefoldername" value="<?php echo $subfolder->post_title ?>">
                   </li>
                   <li class="uk-margin-small-bottom">
                     <button class="uk-button uk-button-primary uk-button-small uk-width-1-1" onclick="admin2020renamefolder(<?php echo $subfolder->ID?>);"><?php _e('Update','admin2020') ?></button>
                   </li>
                   <li>
                     <button class="uk-button uk-button-danger uk-button-small uk-width-1-1" onclick="admin2020deletefolder(<?php echo $subfolder->ID?>);"><?php _e('Delete','admin2020') ?></button>
                   </li>
                 </ul>
               </div>
              <span class="uk-badge admin2020folderCount">0</span>
            </div>
          </div>

          <?php

        } /// END OF PARENT CHECK

        if ($counter == count($folders)){
          ?>
          </div>
          <?php
        }

      }



    }}

  }



  public function get_folders_media_view($activeid){



    $args = array(
      'numberposts' => -1,
      'post_type'   => 'admin2020folders',
      'orderby' => 'title',
      'order'   => 'ASC',
    );

    $folders = get_posts( $args );

    if (count($folders) < 1){
      ?>
      <p class="uk-text-meta"><?php _e('No folders yet, why not create one?','admin2020') ?></p>
      <?php
      return;
    }

    ?>
    <div class="admin2020folder admin2020allFolders">
      <a uk-filter-control="group: folders" href="#" class="admin2020folderTitle uk-link-muted"><span class="uk-margin-small-right" uk-icon="icon: folder"></span><?php _e('All','admin2020') ?></a>
    </div>

    <?php

    foreach ($folders as $folder){

      $parent_folder = get_post_meta($folder->ID, "parent_folder",true);
      $activeclass = "";
      if($activeid == $folder->ID){
        $activeclass = "uk-active";
      }
      if (!$parent_folder){
      ?>

      <div class="admin2020folder" uk-toggle="target: #subfolder<?php echo $folder->ID?>" folder-id="<?php echo $folder->ID?>">
        <a href="#" uk-filter-control="filter: .folder<?php echo $folder->ID?>;group: folders" class="admin2020folderTitle uk-link-muted <?php echo $activeclass?>"><span class="uk-margin-small-right" uk-icon="icon: folder"></span><?php echo $folder->post_title ?></a>
      </div>



      <?php

      $counter = 0;
      foreach ($folders as $subfolder){

        $currentfolder = $folder->ID;
        $parentfolder = get_post_meta($subfolder->ID, "parent_folder",true);

        $activeclass = "";
        $hider = 'hidden';

        if($activeid == $subfolder->ID){
          $activeclass = "uk-active";
        }

        foreach ($folders as $quickcheck){
          if($activeid == $quickcheck->ID && get_post_meta($quickcheck->ID, "parent_folder",true) == $currentfolder){
            $hider = 'aria-hidden="false"';
          }
        }

        if ($counter == 0){
          ?>
          <div id="subfolder<?php echo $folder->ID?>" class="admin2020subFolderWrap" <?php echo $hider?>>
          <?php
        }
        $counter = $counter + 1;

        if ($parentfolder == $currentfolder){




          ?>
          <div class="admin2020folder subfolder" folder-id="<?php echo $subfolder->ID?>">
            <a href="#" uk-filter-control="filter: .folder<?php echo $subfolder->ID?>;group: folders" class="admin2020folderTitle uk-link-muted <?php echo $activeclass?>"><span class="uk-margin-small-right" uk-icon="icon: folder"></span><?php echo $subfolder->post_title ?></a>
          </div>

          <?php

        } /// END OF PARENT CHECK

        if ($counter == count($folders)){
          ?>
          </div>
          <?php
        }

      }



    }}
  }


  public function admin2020_get_media_later() {
      if (defined('DOING_AJAX') && DOING_AJAX && check_ajax_referer('ma-admin-security-nonce', 'security') > 0) {
          $media_index = $_POST['media_index'];

          echo $this->build_media($media_index,0);

      }
      die();
  }

  public function admin2020_save_attachment() {
      if (defined('DOING_AJAX') && DOING_AJAX && check_ajax_referer('ma-admin-security-nonce', 'security') > 0) {
          $title = $_POST['title'];
          $imgalt = $_POST['imgalt'];
          $caption = $_POST['caption'];
          $description = $_POST['description'];
          $imgid = $_POST['imgid'];

          $attachment = array(
            'ID' => strip_tags($imgid),
            'post_title' => strip_tags($title),
            'post_content' => strip_tags($description),
            'post_excerpt' => strip_tags($caption),
          );
          update_post_meta( $imgid, '_wp_attachment_image_alt', $imgalt);

          wp_update_post( $attachment);
          //print_r($errors);
          echo $this->build_media(0,0);

      }
      die();
  }

  public function admin_media_render() {

    ?>
    <div uk-filter="target: .admin2020_media_gallery" id="admin2020_media_gallery_filter">
      <?php
      $this->build_nav();
      ?>
      <div class="uk-grid">

        <div class="admin2020folders" style="width:400px;padding-right:30px;" hidden>
          <?php $this->build_folders(); ?>
        </div>

        <div uk-grid="" class="admin2020_media_gallery uk-width-expand">
        <?php $this->build_media(0,30);?>
        </div>

      </div>

    </div>
    <?php

    $this->build_viewer();
    $this->build_uploader();
    $this->loadscripts();

  }

  public function build_folders(){

    ?>

    <div class="holder" uk-sticky="top: 200;offset:140;cls-active: foldersfixed">
      <div class="uk-width-1-1 uk-margin-bottom" style="float:left">

        <div>

          <div class="admin2020folder admin2020allFolders" ondrop="admin2020mediadrop(event)" ondragover="admin2020mediaAllowDrop(event)" ondragleave="admin2020mediaDropOut(event)">
            <a uk-filter-control="group: folders" href="#" class="admin2020folderTitle uk-link-muted"><span class="uk-margin-small-right" uk-icon="icon: folder"></span><?php _e('All','admin2020') ?></a>
            <div style="float:right;">
              <span class="uk-badge admin2020totalCount">0</span>
            </div>
          </div>

          <div id="admin2020folderswrap">

            <?php $this->get_folders(0)?>

          </div>

        </div>

      </div>

      <div class="uk-margin-bottom">

        <a href="#" class="admin2020folderTitle uk-text-meta" uk-toggle="target: .admin2020createfolder"><span class="uk-margin-small-right" uk-icon="icon: plus-circle"></span><?php _e('Create New','admin2020') ?></a>
        <div class="uk-margin-top admin2020createfolder" hidden>
          <input type="text" class="uk-input uk-margin-bottom" id="foldername" placeholder="Folder Name">
          <button class="uk-button uk-button-primary uk-width-1-1" onclick="admin2020newfolder()" type="button"><?php _e('Create','admin2020') ?></button>
        </div>

      </div>

      <hr>

      <div class="" >

        <div id="selectedfilters">
          <span id="month"></span>
          <span id="year"></span>
          <span id="user"></span>
          <span class="uk-label admin2020filterControlalll" uk-filter-control id="clearall" style="cursor:pointer;display:none;">Clear Filters</span>
        </div>
        <ul uk-accordion>
            <li>

                <a class="uk-accordion-title uk-text-meta" href="#">Advanced Filters</a>

                <div class="uk-accordion-content">

                  <button class="uk-button uk-button-default">Order By</button>
                  <div uk-dropdown="mode: click">
                      <ul class="uk-nav uk-dropdown-nav">
                        <li uk-filter-control="sort: admin2020_uploaded_on;group: orderby"><a href="#"><?php _e('Date Created (Oldest first)','admin2020') ?></a></li>
                        <li uk-filter-control="sort: admin2020_uploaded_on;order: desc;group: orderby"><a href="#"><?php _e('Date Created (Newest first)','admin2020') ?></a></li>
                        <li uk-filter-control="sort: admin2020_file_size_order;group: orderby;filter: .admin2020_attachment"><a href="#"><?php _e('File Size (Smallest First)','admin2020') ?></a></li>
                        <li uk-filter-control="sort: admin2020_file_size_order;order: desc;group: orderby;filter: .admin2020_attachment"><a href="#"><?php _e('File Size (Biggest First)','admin2020') ?></a></li>
                      </ul>
                  </div>

                  <div class="uk-width-1-1 uk-margin-top uk-grid-small" uk-grid>

                    <div class="uk-text-meta uk-width-1-1">Filter By Date:</div>

                    <div class="uk-width-1-2">
                      <button class="uk-button uk-button-default uk-width-1-1">Month</button>
                      <div uk-dropdown="mode: click">
                          <ul class="uk-nav uk-dropdown-nav">
                            <li class="admin2020filterControlmonth" uk-filter-control="group: months"><a href="#">All</a></li>
                            <li class="uk-nav-divider" style="margin: 10px 0;"></li>
                            <?php
                            for($m=1; $m<=12; ++$m){
                                $month = date('F', mktime(0, 0, 0, $m, 1));
                                ?>
                                <li class="admin2020filterControlmonth" uk-filter-control="filter: [admin2020_month_filter='<?php echo $month ?>'];group: months"><a href="#"><?php echo $month ?></a></li>
                                <?php
                            }
                             ?>
                          </ul>
                      </div>
                    </div>

                    <div class="uk-width-1-2">
                      <button class="uk-button uk-button-default uk-width-1-1">Year</button>
                      <div uk-dropdown="mode: click">
                        <ul class="uk-nav uk-dropdown-nav">
                          <li class="admin2020filterControlmonth" uk-filter-control="group: years"><a href="#">All</a></li>
                          <li class="uk-nav-divider" style="margin: 10px 0;"></li>
                          <?php
                          $today = date("Y-m-d");
                          for($m=0; $m<=5; ++$m){

                              $year = date('Y', strtotime($today." - ".$m." years"));
                              ?>
                              <li class="admin2020filterControlyear" uk-filter-control="filter: [admin2020_year_filter='<?php echo $year ?>'];group: years"><a href="#"><?php echo $year ?></a></li>
                              <?php
                          }
                           ?>
                        </ul>
                      </div>
                    </div>

                  </div>


                  <div class="uk-width-1-1 uk-margin-top uk-grid-small" uk-grid>

                    <div class="uk-text-meta uk-width-1-1">Uploaded By:</div>

                    <div class="uk-width-1-1">
                      <button class="uk-button uk-button-default uk-width-1-1">Username</button>
                      <div uk-dropdown="mode: click">
                          <ul class="uk-nav uk-dropdown-nav">
                            <li class="admin2020filterControluser" uk-filter-control="group: user"><a href="#">All</a></li>
                            <li class="uk-nav-divider" style="margin: 10px 0;"></li>
                            <?php

                            $blogusers = get_users();

                            foreach($blogusers as $user){
                                $username = $user->display_name;
                                ?>
                                <li class="admin2020filterControluser" uk-filter-control="filter: [admin2020_user_filter='<?php echo $username ?>'];group: user"><a href="#"><?php echo $username ?></a></li>
                                <?php
                            }
                             ?>
                          </ul>
                      </div>
                    </div>

                  </div>

                </div>
            </li>

        </ul>
      </div>

  </div>

    <?php

  }

  public function build_nav(){
    ?>
    <h1 class="uk-margin-remove-top uk-margin-bottom"><?php _e('Media Library','admin2020') ?></h1>
    <div class="uk-position-top-right uk-padding-large admin2020topbutton">
      <button class="page-title-action" uk-toggle="target: #admin2020uploader"><?php _e('Upload','admin2020') ?></button>
    </div>
    <div class="uk-padding uk-padding-remove-horizontal uk-flex uk-flex-between" style="width:100%;">

      <ul class="uk-iconnav">
      <li><button class="uk-button uk-button-default" uk-toggle="target: .admin2020folders" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: folder"></span></button></li>
      <li><button class="uk-button uk-button-default" id="admin2020listView" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: list"></span></button></li>
      <li><button class="uk-button uk-button-default" id="admin2020gridView" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: grid"></span></button></li>
      <li><button class="uk-button uk-button-default" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: search"></span></button></li>
      <div uk-drop="mode: click;pos:right-center">
        <div class="uk-inline">
            <span class="uk-form-icon" uk-icon="icon: search"></span>
            <input class="uk-input" id="admin2020mediaSearch" placeholder="Search media..." autofocus>
        </div>
      </div>
      </ul>

      <ul class="uk-iconnav">
        <li><button class="uk-button uk-button-default uk-visible@m" uk-filter-control="group: type" style="padding-left:10px;padding-right:10px;">ALL</button></li>
        <li><button class="uk-button uk-button-default uk-visible@m" uk-filter-control="filter: [admin2020_file_filter='image'];group: type" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: image"></span></button></li>
        <li><button class="uk-button uk-button-default uk-visible@m" uk-filter-control="filter: [admin2020_file_filter='video'];group: type" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: video-camera"></span></button></li>
        <li><button class="uk-button uk-button-default uk-visible@m" uk-filter-control="filter: [admin2020_file_filter='audio'];group: type" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: microphone"></span></button></li>
        <li><button class="uk-button uk-button-default uk-visible@m" uk-filter-control="filter: [admin2020_file_filter='application'];group: type" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: file-pdf"></span></button></li>
        <li><button class="uk-button uk-button-default hidden admin2020_delete_multiple uk-text-danger" style="padding-left:10px;padding-right:10px;" type="button" onclick="admin2020_delete_multiple_attachment()"><span uk-icon="icon:trash"></span></button></li>
      </ul>


    </div>
    <?php
  }

  public function build_media($startingpoint,$endpoint){


    $args = array(
    'post_type' => 'attachment',
    'numberposts' => -1,
    'post_status' => null,
    'post_parent' => null,
    );
    $attachments = get_posts($args);
    $tracker = "";
    $count = 0;

    if ($endpoint == 0){
      $endpoint = count($attachments)-1;
    } else {
      if ($endpoint < count($attachments)-1){
        ?>
        <script>
             get_media_later(<?php echo $endpoint+1?>);
        </script>
        <?php
      }
    }
    ?>

      <?php
      if ($attachments) {

        for($i = $startingpoint; $i <= $endpoint; $i++) {

          $attachment = $attachments[$i];

          $postdate = $attachment->post_date;
          $attachmenttype = $attachment->post_mime_type;
          $pieces = explode("/", $attachmenttype);
          $maintype = $pieces[0];

          if (date('d/m/Y',strtotime($postdate)) == date('d/m/Y')){
            $stamp = "Today";
          } else {
            $stamp = human_time_diff( date('U',strtotime($postdate)), current_time('timestamp') )  . ' ago';
          }

          if ($stamp != $tracker){
            ?>
            <div admin2020_file_size_order="" admin2020_uploaded_on="<?php echo date("Y-m-d",strtotime($postdate))?>" class="uk-width-1-1 uk-text-meta admin2020dateSep"><?php echo $stamp ?></div><?php
          }

          $tracker = $stamp;

          //$attachmentmeta = wp_get_attachment_metadata( $attachment->ID);
          //print_r($attachmentmeta);
          //echo '<pre>' . print_r( $attachmentmeta, true ) . '</pre>';
          $caption = $attachment->post_excerpt;
          $filesize = filesize( get_attached_file( $attachment->ID ) );

          $attachmentid = $attachment->ID;
          $postdate = $attachment->post_date;
          $uploadedon =date('Y-m-d',strtotime($postdate));
          $month =date('F',strtotime($postdate));
          $year =date('Y',strtotime($postdate));
          $attachmentFullSize = wp_get_attachment_url($attachmentid);
          $alt_text = get_post_meta($attachmentid , '_wp_attachment_image_alt', true);
          $folders = get_post_meta($attachmentid , 'admin2020_folder', true);
          $userid = $attachment->post_author;
          $user = get_user_by('ID',$userid);



          if (strpos($attachmenttype, 'image') !== false) {

            $attachmentinfo = wp_get_attachment_image_src($attachmentid, 'medium');
            $src = $attachmentinfo[0];
            $width = $attachmentinfo[1];
            $height = $attachmentinfo[2];
            $dimensions = $width."px ".$height."px";
            ?>
            <div draggable="true" ondragstart="admin2020mediadrag(event)" id="attachment<?php echo esc_html($attachmentid)?>" admin2020_filename="<?php echo esc_html($attachment->post_title)?>"
            admin2020_folders="<?php echo esc_html($folders)?>"
            admin2020_type="<?php echo esc_html($attachmenttype)?>"
            admin2020_attachmentid="<?php echo esc_html($attachmentid)?>"
            admin2020_uploaded_on="<?php echo esc_html($uploadedon)?>"
            admin2020_file_size="<?php echo esc_html($this->formatBytes($filesize))?>"
            admin2020_file_size_order="<?php echo esc_html($filesize)?>"
            admin2020_image_src="<?php echo esc_html($attachmentFullSize)?>"
            admin2020_file_dimensions="<?php echo esc_html($dimensions)?>"
            admin2020_file_alt="<?php echo esc_html($alt_text)?>"
            admin2020_file_caption="<?php echo esc_html($attachment->post_excerpt)?>"
            admin2020_file_description="<?php echo esc_html($attachment->post_content)?>"
            admin2020_file_filter="<?php echo esc_html($maintype)?>"
            admin2020_month_filter="<?php echo esc_html($month)?>"
            admin2020_year_filter="<?php echo esc_html($year)?>"
            admin2020_user_filter="<?php echo esc_html($user->display_name)?>"
            class="admin2020_attachment" onclick="admin2020_attachment_info(this,event)">
              <div style="position:relative;height:100%">
                <img data-src="<?php echo $src?>" class="admin2020_attachment_preview" style="max-height:150px" uk-img>
                <div class="admin2020_meta">
                  <div class="uk-position-top-left uk-padding-small admin2020_media_select_holder" style="z-index: 1;">
                    <input admin2020_attachmentid="<?php echo esc_html($attachmentid)?>" type="checkbox" class="uk-input admin2020_media_select" onclick="admin2020_multiple_select()">
                  </div>
                  <div class="uk-position-bottom uk-padding-small admin2020attachmenttext uk-light">
                    <span class="title"><?php echo esc_html($attachment->post_title)?></span>
                    <span class="uk-text-meta"><?php echo esc_html($attachment->post_excerpt)?></span>
                  </div>
                </div>
              </div>
            </div>
            <?php
          } else if (strpos($attachmenttype, 'video') !== false) {
            $attachmentid = $attachment->ID;
            $src = $attachment->guid;
            //echo $video_meta['length_formatted'];
            ?>
            <div draggable="true" ondragstart="admin2020mediadrag(event)" id="attachment<?php echo esc_html($attachmentid)?>" admin2020_filename="<?php echo esc_html($attachment->post_title)?>"
            admin2020_type="<?php echo esc_html($attachmenttype)?>"
            admin2020_folders="<?php echo esc_html($folders)?>"
            admin2020_attachmentid="<?php echo esc_html($attachmentid)?>"
            admin2020_uploaded_on="<?php echo esc_html($uploadedon)?>"
            admin2020_file_size="<?php echo esc_html($this->formatBytes($filesize))?>"
            admin2020_file_size_order="<?php echo esc_html($filesize)?>"
            admin2020_image_src="<?php echo esc_html($src)?>"
            admin2020_file_dimensions=""
            admin2020_file_alt="<?php echo esc_html($alt_text)?>"
            admin2020_file_caption="<?php echo esc_html($attachment->post_excerpt)?>"
            admin2020_file_description="<?php echo esc_html($attachment->post_content)?>"
            admin2020_file_filter="<?php echo esc_html($maintype)?>"
            admin2020_month_filter="<?php echo esc_html($month)?>"
            admin2020_year_filter="<?php echo esc_html($year)?>"
            admin2020_user_filter="<?php echo esc_html($user->display_name)?>"
            class="admin2020_attachment" onclick="admin2020_attachment_info(this,event)">
                <div style="position: relative;height:100%">
                  <video class="admin2020_attachment_preview" src="<?php echo $src?>" playsinline controls uk-video="autoplay: false" style="max-height:150px"></video>
                  <div class="admin2020_meta">
                    <div class="uk-position-top-left uk-padding-small admin2020_media_select_holder" style="z-index: 1;">
                      <input admin2020_attachmentid="<?php echo esc_html($attachmentid)?>" type="checkbox" class="uk-input admin2020_media_select" onclick="admin2020_multiple_select()">
                    </div>
                    <div class="uk-position-bottom uk-padding-small admin2020attachmenttext uk-light">
                      <span class="title"><?php echo esc_html($attachment->post_title)?></span>
                      <span class="uk-text-meta"><?php echo esc_html($attachment->post_excerpt)?></span>
                    </div>
                  </div>
               </div>
            </div>
            <?php
          } else if (strpos($attachmenttype, 'application') !== false) {
            $attachmentid = $attachment->ID;
            $src = $attachment->guid;
            //echo $video_meta['length_formatted'];
            ?>
            <div draggable="true" ondragstart="admin2020mediadrag(event)" id="attachment<?php echo esc_html($attachmentid)?>" admin2020_filename="<?php echo esc_html($attachment->post_title)?>"
            admin2020_type="<?php echo esc_html($attachmenttype)?>"
            admin2020_folders="<?php echo esc_html($folders)?>"
            admin2020_image_src="<?php echo esc_html($src)?>"
            admin2020_attachmentid="<?php echo esc_html($attachmentid)?>"
            admin2020_uploaded_on="<?php echo esc_html($uploadedon)?>"
            admin2020_file_size="<?php echo esc_html($this->formatBytes($filesize))?>"
            admin2020_file_size_order="<?php echo esc_html($filesize)?>"
            admin2020_file_caption="<?php echo esc_html($attachment->post_excerpt)?>"
            admin2020_file_description="<?php echo esc_html($attachment->post_content)?>"
            admin2020_file_filter="<?php echo esc_html($maintype)?>"
            admin2020_month_filter="<?php echo esc_html($month)?>"
            admin2020_year_filter="<?php echo esc_html($year)?>"
            admin2020_user_filter="<?php echo esc_html($user->display_name)?>"
            class="admin2020_attachment" onclick="admin2020_attachment_info(this,event)">
                <div class="uk-flex uk-flex-center uk-flex-middle admin2020standardBackground admin2020_attachment_preview" style="height:150px;width:150px">
                  <span uk-icon="icon: file-pdf;ratio:3"></span>
                </div>
                <div class="admin2020_meta" style="height:150px;width:150px">
                  <div class="uk-position-top-left uk-padding-small admin2020_media_select_holder" style="z-index: 1;">
                    <input admin2020_attachmentid="<?php echo esc_html($attachmentid)?>" type="checkbox" class="uk-input admin2020_media_select" onclick="admin2020_multiple_select()">
                  </div>
                  <div class="uk-position-bottom uk-padding-small admin2020attachmenttext uk-light">
                    <span class="title"><?php echo esc_html($attachment->post_title)?></span>
                    <span class="uk-text-meta"><?php echo esc_html($attachment->post_excerpt)?></span>
                  </div>
                </div>
            </div>
            <?php
          } else if (strpos($attachmenttype, 'audio') !== false) {
            $attachmentid = $attachment->ID;
            $src = $attachment->guid;
            //echo $video_meta['length_formatted'];
            ?>
            <div draggable="true" ondragstart="admin2020mediadrag(event)" id="attachment<?php echo esc_html($attachmentid)?>" admin2020_filename="<?php echo esc_html($attachment->post_title)?>"
            admin2020_type="<?php echo esc_html($attachmenttype)?>"
            admin2020_folders="<?php echo esc_html($folders)?>"
            admin2020_image_src="<?php echo esc_html($src)?>"
            admin2020_attachmentid="<?php echo esc_html($attachmentid)?>"
            admin2020_uploaded_on="<?php echo esc_html($uploadedon)?>"
            admin2020_file_size="<?php echo esc_html($this->formatBytes($filesize))?>"
            admin2020_file_size_order="<?php echo esc_html($filesize)?>"
            admin2020_file_caption="<?php echo esc_html($attachment->post_excerpt)?>"
            admin2020_file_description="<?php echo esc_html($attachment->post_content)?>"
            admin2020_file_filter="<?php echo esc_html($maintype)?>"
            admin2020_month_filter="<?php echo esc_html($month)?>"
            admin2020_year_filter="<?php echo esc_html($year)?>"
            admin2020_user_filter="<?php echo esc_html($user->display_name)?>"
            class="admin2020_attachment" onclick="admin2020_attachment_info(this,event)">
                <div class="uk-flex uk-flex-center uk-flex-middle admin2020standardBackground admin2020_attachment_preview" style="height:150px;width:150px">
                  <span uk-icon="icon: microphone;ratio:3"></span>
                </div>
                <div class="admin2020_meta" style="height:150px;width:150px">
                  <div class="uk-position-top-left uk-padding-small admin2020_media_select_holder" style="z-index: 1;">
                    <input admin2020_attachmentid="<?php echo esc_html($attachmentid)?>" type="checkbox" class="uk-input admin2020_media_select" onclick="admin2020_multiple_select()">
                  </div>
                  <div class="uk-position-bottom uk-padding-small admin2020attachmenttext uk-light">
                    <span><?php echo esc_html($attachment->post_title)?></span>
                    <span class="uk-text-meta"><?php echo esc_html($attachment->post_excerpt)?></span>
                  </div>
                </div>
            </div>
            <?php
          }

          $count = $count + 1;

        }
      }
  }

  public function build_viewer(){

    ?>
    <div id="admin2020MediaViewer" uk-offcanvas="flip:true;overlay:true" >
        <div class="uk-offcanvas-bar uk-padding-remove uk-box-shadow-large" style="width:500px;">

            <span style="display:none" id="admin2020_viewer_currentid"></span>
            <button class="uk-offcanvas-close" type="button" uk-close></button>

            <div style="float: left;position: relative;width: 100%;margin-bottom:30px;">
              <img id="admin2020imgViewer" src="" class="uk-image" style="width:100%;display:none;"></>
              <video id="admin2020videoViewer" playsinline controls uk-video="autoplay: false" style="width:100%;display:none;"></video>

              <div id="admin2020docViewer" class="uk-flex uk-flex-center uk-flex-middle  uk-margin-bottom" style="width:100%;height:200px;float:left;display:none">
                <span uk-icon="icon: file-pdf;ratio:4"></span>
              </div>

              <div class="uk-padding" id="admin2020audioViewer" style="width:100%;display:none;float:left">
                <video id="admin2020audioplayer" playsinline controls uk-video="autoplay: false" style="min-width:100%;float:left;width:100%;"></video>
              </div>
              <button class="uk-position-small uk-position-center-left admin2020imageshift" type="button" onclick="switchinfo('left')">
                <span uk-icon="icon:chevron-left"></span>
              </button>
              <button class="uk-position-small uk-position-center-right admin2020imageshift" type="button" onclick="switchinfo('right')">
                <span uk-icon="icon:chevron-right"></span>
              </button>
            </div>

            <div class="uk-padding">
              <h4 class="" id="admin2020_viewer_title">Image Title</h4>
              <div id="admin2020MainMeta" class="uk-text-meta uk-margin-bottom" hidden>
                <div class="uk-width-1-1"><strong>File Type: </strong> <span  id="admin2020_type"></span></div>
                <div class="uk-width-1-1"><strong>File Uploaded on: </strong><span  id="admin2020_uploaded_on"></span></div>
                <div class="uk-width-1-1"><strong>File Size: </strong><span  id="admin2020_file_size"></span></div>
                <div class="uk-width-1-1"><strong>Dimensions: </strong><span  id="admin2020_file_dimensions"></span></div>
              </div>
              <a href="#" uk-toggle="target: #admin2020MainMeta" class="uk-text-meta" id="">Toggle Meta</a>
              <form class="uk-form uk-margin-top">
                <div class="uk-margin">
                    <input class="uk-input" id="admin2020_viewer_altText" type="text" placeholder="Alt Text">
                </div>
                <div class="uk-margin">
                    <input class="uk-input" id="admin2020_viewer_input_title" type="text" placeholder="Title">
                </div>
                <div class="uk-margin">
                    <textarea class="uk-input" id="admin2020_viewer_caption" type="text" style="height:60px;" placeholder="Caption"></textarea>
                </div>
                <div class="uk-margin">
                    <textarea class="uk-input" id="admin2020_viewer_description" type="text" style="height:60px;" rows="2" placeholder="Description"></textarea>
                </div>
                <div class="uk-margin" style="position:relative">
                  <div class="uk-inline uk-width-1-1" onclick="copythis(this)" style="cursor:pointer">
                    <span class="uk-form-icon" uk-icon="icon:copy"></span>
                    <input class="uk-input" id="admin2020_viewer_fullLink" value="http://localhost/adminplugin/wp-content/uploads/2020/05/camping-kettle-and-coffee-cup-scaled.jpg">
                  </div>
                  <span class="uk-text-success" id="linkcopied" style="display:none;position: absolute;left: 0;top: 120%;">Link copied to clipboard</span>
                </div>
                <div class="uk-margin-large uk-margin-remove-bottom">
                  <button class="uk-button uk-button-primary" type="button" onclick="admin2020_save_attachment()">Save</button>
                  <button class="uk-button uk-button-primary uk-align-right" type="button" onclick="admin2020_delete_attachment()"><span class="uk-text-danger" uk-icon="icon:trash"></span></button>
                </div>
              </form>
            </div>
        </div>
    </div>


    <?php


  }


  public function build_uploader(){


    $maxupload = $this->file_upload_max_size();

    ?>

    <div class="admin2020_loader_wrapper" style="display:none" onclick="UIkit.offcanvas('#admin2020uploader').show();">
      <div class="admin2020uploadMonitor uk-box-shadow-large">
        <span class="status uk-text-meta ">
          <span uk-icon="icon: cloud-upload"></span>
          <span class="admin2020upstat"></span>
        </span>
      </div>
    </div>

    <div id="admin2020uploader" uk-offcanvas="flip:true;overlay:true" >
        <div class="uk-offcanvas-bar uk-box-shadow-large" style="width:500px;">

          <div class="js-upload uk-placeholder uk-text-center" id="admin2020droparea" style="border-radius:4px;">
              <span uk-icon="icon: cloud-upload"></span>
              <span class="uk-text-middle"><?php _e('Drop items here or','admin2020') ?> </span>
              <div uk-form-custom>
                  <input id="admin2020upload" type="file" multiple>
                  <span class="uk-link"><?php _e('select them','admin2020') ?></span>
              </div>
          </div>

          <div id="max-upload-size" style="display:none;"><?php echo $maxupload?></div>

          <div class="admin2020uploadItems uk-margin-large-top uk-grid-small uk-child-width-1-1" uk-grid>


          </div>


        </div>
    </div>


    <?php


  }

  public function loadscripts(){
    ?>
    <script>
    dropArea = document.getElementById('admin2020droparea');
    functions = ['dragenter', 'dragover', 'dragleave', 'drop'];
    ins = ['dragenter', 'dragover'];
    outs = ['dragleave', 'drop'];

    jQuery.each(functions, function(i, obj) {
      dropArea.addEventListener(obj, preventDefaults, false)
    })

    function preventDefaults (e) {
      e.preventDefault()
      e.stopPropagation()
    }

    jQuery.each(ins, function(i, obj) {
      dropArea.addEventListener(obj, highlight, false)
    })

    jQuery.each(outs, function(i, obj) {
      dropArea.addEventListener(obj, unhighlight, false)
    })

    function highlight(e) {
      dropArea.classList.add('highlight')
    }

    function unhighlight(e) {
      dropArea.classList.remove('highlight')
    }

    dropArea.addEventListener('drop', handleDrop, false)

    function handleDrop(e) {
      dt = e.dataTransfer
      files = dt

      preupload(files);
    }
    </script>
    <?php
  }


  public function formatBytes($size, $precision = 0){
      $base = log($size, 1024);
      $suffixes = array('', 'Kb', 'Mb', 'Gb', 'Tb');

      return round(pow(1024, $base - floor($base)), $precision) .' '. $suffixes[floor($base)];
  }


  public function file_upload_max_size() {
    static $max_size = -1;

    if ($max_size < 0) {

      $post_max_size = $this->parse_size(ini_get('post_max_size'));
      if ($post_max_size > 0) {
        $max_size = $post_max_size;
      }

      $upload_max = $this->parse_size(ini_get('upload_max_filesize'));
      if ($upload_max > 0 && $upload_max < $max_size) {
        $max_size = $upload_max;
      }
    }
    return $max_size;
  }

  public function parse_size($size) {
    $unit = preg_replace('/[^bkmgtpezy]/i', '', $size); // Remove the non-unit characters from the size.
    $size = preg_replace('/[^0-9\.]/', '', $size); // Remove the non-numeric characters from the size.
    if ($unit) {
      return round($size * pow(1024, stripos('bkmgtpezy', $unit[0])));
    } else {
      return round($size);
    }
  }

  function override_media_templates(){
      ?>
      <!-- BUILD FOLDERS IN MODAL -->
      <script type="text/html" id="tmpl-media-frame_custom">
      		<div class="media-frame-title" id="media-frame-title"></div>
      		<h2 class="media-frame-menu-heading"><?php _ex( 'Actions', 'media modal menu actions' ); ?></h2>
      		<button type="button" class="button button-link media-frame-menu-toggle" aria-expanded="false">
      			<?php _ex( 'Menu', 'media modal menu' ); ?>
      			<span class="dashicons dashicons-arrow-down" aria-hidden="true"></span>
      		</button>
      		<div class="media-frame-menu"></div>
      		<div class="media-frame-tab-panel">
      			<div class="media-frame-router"></div>

            <div class="uk-grid-collapse" uk-grid uk-filter="target: .attachments" style="max-height: 100%;overflow: auto;">
              <div class="uk-width-medium uk-padding">
                <div style="position:fixed">

                  <div style="float:left;margin-top:80px;">
                    <ul class="uk-iconnav admin2020iconnav uk-margin">
                      <li ><button class="uk-button uk-button-default uk-visible@m" uk-filter-control="group: type" style="padding-left:10px;padding-right:10px;">ALL</button></li>
                      <li ><button class="uk-button uk-button-default uk-visible@m" uk-filter-control="filter: .filter-image;group: type" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: image"></span></button></li>
                      <li ><button class="uk-button uk-button-default uk-visible@m" uk-filter-control="filter: .filter-video;group: type" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: video-camera"></span></button></li>
                      <li ><button class="uk-button uk-button-default uk-visible@m" uk-filter-control="filter: .filter-audio;group: type" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: microphone"></span></button></li>
                      <li ><button class="uk-button uk-button-default uk-visible@m" uk-filter-control="filter: .filter-application;group: type" style="padding-left:10px;padding-right:10px;"><span href="#" uk-icon="icon: file-pdf"></span></button></li>
                    </ul>

                    <ul class="uk-iconnav admin2020iconnav">
                      <div class="uk-margin">
                          <div class="uk-inline">
                              <span class="uk-form-icon" uk-icon="icon: search"></span>
                              <input class="uk-input" type="text" id="admin2020mediaSearchModal" onkeyup="admin2020searchAtachments(this)" placeholder="Search media..." autofocus>
                          </div>
                      </div>
                    </ul>
                  </div>

                  <div id="admin2020folderswrap" >
                    <?php
                    $folders = new Admin_2020_Media(0);
                    $folders->get_folders_media_view(0);
                    ?>
                  </div>
                </div>
              </div>
              <div class="uk-width-expand uk-overflow-hidden" style="max-height:100%;" >
          			<div class="media-frame-content"></div>
              </div>
            </div>
      		</div>
      		<h2 class="media-frame-actions-heading screen-reader-text">
      		<?php
      			/* translators: Accessibility text. */
      			_e( 'Selected media actions' );
      		?>
      		</h2>
      		<div class="media-frame-toolbar"></div>
      		<div class="media-frame-uploader"></div>
      	</script>
      <script>
          jQuery(document).ready( function($) {

              if( typeof wp.media.view.Attachment != 'undefined' ){
                  //console.log(wp.media.view);
                  //wp.media.view.Attachment.prototype.template = wp.media.template( 'attachment_custom' );
                  wp.media.view.MediaFrame.prototype.template = wp.media.template( 'media-frame_custom' );

                  wp.media.view.Attachment.Library = wp.media.view.Attachment.Library.extend({
                    className: function () { return 'attachment folder' + this.model.get( 'folderid' ); },
                    folderName: function () { return 'attachment ' + this.model.get( 'folderid' ); },
                  });

                  wp.media.view.Modal.prototype.on('open', function() {
                    //MODAL OPEN
              			//refreshFolderCountModal();
              		});


              }
          });
      </script>
      <?php
  }

  /////END OF CLASS

}
