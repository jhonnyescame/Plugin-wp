<?php
class Admin_2020_Styles {

  private $version;

  public function __construct( $theversion ) {

    $this->version = $theversion;

  }

  public function load(){

    add_action('admin_enqueue_scripts', array( $this, 'add_styles' ),0);
    add_action('admin_init', array( $this, 'remove_styles' ));
    add_action('login_enqueue_scripts', array( $this, 'add_login_styles' ));
    add_action('admin_head', array( $this, 'change_primary_link_color' ),0);

    //WORKAROUND TO STOP MAIL POET DISABLING CUSTOM STYLES
    add_filter('mailpoet_conflict_resolver_whitelist_style',array($this,'admin2020_mailPoet_workaround'),-999);
    add_filter('mailpoet_conflict_resolver_whitelist_script',array($this,'admin2020_mailPoet_workaround_scripts'),-999);


  }


  /// FIX FOR MAIL POET

  public function admin2020_mailPoet_workaround($whitelistedStyles) {

      $requiredcss = array("ma-admin-common.min.css","ma-admin-head.min.css","ma-admin-menu.min.css","ma-admin-mobile.min.css","uikit.min.css","mailpoet.min.css");

      foreach($requiredcss as $stylesheet){
        $whitelistedStyles[] = $stylesheet;
      }

	    return $whitelistedStyles;
  }

  public function admin2020_mailPoet_workaround_scripts($whitelistedScripts) {

      $requiredscripts = array("uikit-icons.min.js","uikit.min.js","ma.admin.min.js");

      foreach($requiredscripts as $script){
        $whitelistedScripts[] = $script;
      }

	    return $whitelistedScripts;
  }



  public function change_primary_link_color(){
    $options = get_option('admin2020_settings');
    if(isset($options['admin2020_overiew_primary_color'])){
      if ($options['admin2020_overiew_primary_color'] != ""){
        $color = $options['admin2020_overiew_primary_color'];
        $darkercolor = $this->color_luminance($color,-0.3);
        $much_darkercolor = $this->color_luminance($color,.8);
        echo '<style type="text/css"> .uk-link, .uk-text-primary, .uk-nav-default>li.uk-active>a {  color:'.$color.'  !important; }
              input[type=checkbox]:checked { background-color:'.$color.'  !important; }
              .uk-tab>.uk-active>a { border-color:'.$color.'  !important; }
              .uk-button-primary, .button-primary, .page-title-action { background-color:'.$color.'  !important; border-color: '.$color.';}
              .uk-button-primary:hover, .button-primary:hover, .page-title-action:hover { background-color:'.$darkercolor.'  !important; border-color: '.$darkercolor.';}
              .uk-badge:not(.admin2020notificationBadge):not(.admin2020folderCount):not(.admin2020totalCount){ background-color:'.$color.'  !important; }
              .filter-links li a.current, .subsubsub li a.current {  color:'.$color.'  !important; }
              .admin2020loaderwrap .admin2020loader{background:'.$much_darkercolor.'  !important;}
              .admin2020loader::after {background:'.$color.'  !important;}
              a {  color:'.$color.'; }
              a:hover {  color:'.$darkercolor.'; }
              .row-title::after, .uk-link::after {background:'.$darkercolor.'  !important;}
              .ma-admin-dark .uk-button-primary, .ma-admin-dark .uk-badge{
                  color: #fff !important;
                }
                .uk-offcanvas-bar .uk-button-primary, .uk-offcanvas-bar .uk-badge{
                    color: #fff !important;
                  }
        </style>';
      }
    }

  }

  public function add_styles(){

    global $pagenow;
		$required_styles = array('editor','head','menu','mobile');
    $this->keepstyles = array();

		///LOAD REQUIRED SCRIPTS
    //LOAD UIKIT
    wp_register_style('uikitcss', 'https://cdn.jsdelivr.net/npm/uikit@3.4.2/dist/css/uikit.min.css', false);
    wp_enqueue_style('uikitcss');
    wp_enqueue_script('uikit', 'https://cdn.jsdelivr.net/npm/uikit@3.4.2/dist/js/uikit.min.js', array());
    wp_enqueue_script('uikiticons', 'https://cdn.jsdelivr.net/npm/uikit@3.4.2/dist/js/uikit-icons.min.js', array());
    ////LOAD CHART.JS


    if (isset($_GET['page'])) {
        if($_GET['page']=='admin_2020_dashboard'){
          wp_enqueue_script('admin-chart-js', 'https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js', array('jquery'), $this->version);
          wp_enqueue_script('ma-admin-dashboard', plugin_dir_url(__DIR__) . 'assets/js/ma-admin-dashboard.min.js', array('jquery'), $this->version);
          wp_enqueue_script('ma-admin-dashboard-auth', 'https://apis.google.com/js/client:platform.js', array());

          wp_enqueue_script('ma-admin-moment', 'https://cdn.jsdelivr.net/momentjs/latest/moment.min.js', array());
          wp_enqueue_script('ma-admin-daterangepicker', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js', array('jquery'));
          wp_register_style('ma-admin-daterange-css', 'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css', false);
          wp_enqueue_style('ma-admin-daterange-css');
      }
      if($_GET['page']=='admin_2020_media'){
          wp_enqueue_script('ma-admin-media', plugin_dir_url(__DIR__) . 'assets/js/ma-admin-media.min.js', array('jquery'), $this->version);
          wp_localize_script('ma-admin-media', 'ma_admin_media_ajax', array('ajax_url' => admin_url('admin-ajax.php'), 'security' => wp_create_nonce('ma-admin-media-security-nonce')));
          wp_register_style('custom_wp_media_css', plugin_dir_url(__DIR__) . 'assets/css/ma-admin-media.min.css', array(), $this->version);
          wp_enqueue_style('custom_wp_media_css');
      }
      if($_GET['page']=='admin_2020'){

          wp_enqueue_media();

          wp_enqueue_style( 'wp-color-picker' );
          wp_enqueue_script( 'wp-color-picker');
      }
    }
    //LOAD MEDIA HELPER
    wp_register_script('media-uploader', plugin_dir_url(__DIR__) . 'assets/js/media-uploader.min.js', array('jquery'), $this->version);
    wp_enqueue_script('media-uploader');
		///LOAD GOOGLE FONT
		wp_register_style('custom-google-fonts', 'https://fonts.googleapis.com/css2?family=Sen:wght@400;700&display=swap', array());
    wp_enqueue_style('custom-google-fonts');
		//LOAD ADMIN 2020 JS
    wp_enqueue_script('ma-admin', plugin_dir_url(__DIR__) . 'assets/js/ma-admin.min.js', array('jquery'), $this->version);
    wp_localize_script('ma-admin', 'ma_admin_ajax', array('ajax_url' => admin_url('admin-ajax.php'), 'security' => wp_create_nonce('ma-admin-security-nonce')));

		// LOAD ADMIN 2020 STYLES
		foreach ($required_styles as $style){
			wp_register_style('ma_admin_'.$style.'_css', plugin_dir_url(__DIR__) . 'assets/css/ma-admin-'.$style.'.min.css', array('uikitcss'), $this->version);
	    wp_enqueue_style('ma_admin_'.$style.'_css');
		}

		/// CHECK FOR COMPATIBILITY MODE
    $options = get_option('admin2020_settings');
    if (isset($options['admin2020_disablestyles_field_2'])){
      $disablestyles = $options['admin2020_disablestyles_field_2'];
    } else{
      $disablestyles = false;
    }

		// CONDITIONALLY LOAD EXTRA STYLES
    if ($disablestyles === '1' && $pagenow === "admin.php" && $_GET['page'] != "admin_2020_dashboard" && $_GET['page'] != "admin_2020_media" && $_GET['page'] != "admin_2020")  {
        wp_register_style('custom_wp_admin_css', plugin_dir_url(__DIR__) . 'assets/css/ma-admin-compatibility.min.css', array(), $this->version);
        wp_enqueue_style('custom_wp_admin_css');
    } else if ($pagenow != "customize.php") {
        wp_register_style('custom_wp_admin_css', plugin_dir_url(__DIR__) . 'assets/css/ma-admin-common.min.css', array(), $this->version);
        wp_enqueue_style('custom_wp_admin_css');
    }

    ///CHECK FOR MULTISITE AND ADD ULTIMO
    if(is_multisite()){
      $filelocation = plugin_dir_url(__DIR__) . 'assets/css/extra-plugin/ma-admin-wp-ultimo.min.css';
      wp_register_style('ma_admin_wp_ultimo_css', $filelocation, array(), $this->version);
      wp_enqueue_style('ma_admin_wp_ultimo_css');
    }

		/// CHECK COMPATIBILITY STYLE SHEETS AGAINST INNSTALLED PLUGINS
    $activeplugins = get_option('active_plugins');
    foreach ($activeplugins as $plugin) {
        $string = explode('/', $plugin);
        $pluginname = $string[0];
        $filelocation = plugin_dir_url(__DIR__) . 'assets/css/extra-plugin/ma-admin-' . $pluginname . '.min.css';
        $filepath = plugin_dir_path(__DIR__) . 'assets/css/extra-plugin/ma-admin-' . $pluginname . '.min.css';
        if (file_exists($filepath)) {
            wp_register_style('ma_admin_' . $pluginname . '_css', $filelocation, array(), $this->version);
            wp_enqueue_style('ma_admin_' . $pluginname . '_css');
        }
    }
    wp_register_style('ma_admin_mobile_css', plugin_dir_url(__DIR__) . 'assets/css/ma-admin-mobile.min.css', array(), $this->version);
    wp_enqueue_style('ma_admin_mobile_css');



  }

  public function remove_styles(){

    global $pagenow;

    // CHECK FOR COMPATIBILITY MODE
    $options = get_option('admin2020_settings');
    if (isset($options['admin2020_disablestyles_field_2'])){
      $disablestyles = $options['admin2020_disablestyles_field_2'];
    } else{
      $disablestyles = false;
    }

		/// ARRAY OF STYLES TO DISABLE
    $adminstyles = array("wp-admin", "admin-bar", "buttons", "thickbox");
    $compatability = array("admin-bar", "thickbox", "admin-menu");

		/// STYLES TO LOAD
    $extrastyles = array("common", "forms");
    $customizestyles = array("buttons", "customize-controls", "customize-widgets", "media-views", "customize-nav-menus", "wp-color-picker", "code-editor");

		//CONDITIONALLY DISABLE STYLES
    if ($disablestyles === '1' && $pagenow === "admin.php" && $_GET['page'] != "admin_2020_dashboard" && $_GET['page'] != "admin_2020_media" && $_GET['page'] != "admin_2020") {
        foreach ($compatability as $style) {
            wp_deregister_style($style);
        }
        foreach ($extrastyles as $style) {
            wp_register_style($style, admin_url() . '/css/' . $style . '.css', false, $this->version);
            wp_enqueue_style($style);
        }
    } else if ($pagenow != "customize.php") {
        foreach ($adminstyles as $style) {
            wp_deregister_style($style);
        }
    }



  }


  public function add_login_styles() {

      wp_register_style('uikitcss', plugin_dir_url(__DIR__) . 'assets/css/uikit.min.css', false, '1.0.0');
      wp_enqueue_style('uikitcss');
      wp_enqueue_script('uikit', plugin_dir_url(__DIR__) . 'assets/js/uikit.min.js', array(), '1.0');
      wp_enqueue_script('uikiticons', plugin_dir_url(__DIR__) . 'assets/js/uikit-icons.min.js', array(), '1.0');
      wp_enqueue_style('custom-google-fonts', 'https://fonts.googleapis.com/css2?family=Sen:wght@400;700&display=swap', false);
      wp_register_style('ma-admin-login-css', plugin_dir_url(__DIR__) . 'assets/css/ma-admin-common.min.css', false, '1.0.0');
      wp_enqueue_style('ma-admin-login-css');
      wp_deregister_style('login');

  }


  public function get_version() {
    return $this->version;
  }

  public function color_luminance( $hex, $percent ) {

    	// validate hex string

    	$hex = preg_replace( '/[^0-9a-f]/i', '', $hex );
    	$new_hex = '#';

    	if ( strlen( $hex ) < 6 ) {
    		$hex = $hex[0] + $hex[0] + $hex[1] + $hex[1] + $hex[2] + $hex[2];
    	}

    	// convert to decimal and change luminosity
    	for ($i = 0; $i < 3; $i++) {
    		$dec = hexdec( substr( $hex, $i*2, 2 ) );
    		$dec = min( max( 0, $dec + $dec * $percent ), 255 );
    		$new_hex .= str_pad( dechex( $dec ) , 2, 0, STR_PAD_LEFT );
    	}

    	return $new_hex;
    }

}
