<?php
class Admin_2020_Login{

  private $version;

  public function __construct( $theversion ) {

    $this->version = $theversion;

  }

  public function load(){
    add_action('login_init', array($this,'deregister_default'));
    add_action('login_head', array($this,'ma_admin_login_style'));
    add_action('login_head', array($this,'ma_admin_login_logo'));

    $options = get_option( 'admin2020_settings' );
    if (isset($options['admin2020_overiew_homepage'])){

      if (isset($options['admin2020_disable_overview'])){
          //OVERVIEW IS DISABLED
      } else {
        add_filter( 'login_redirect', array($this,'redirectToOverview') );
      }
    }

  }

  public function redirectToOverview(){
		return home_url() . "/wp-admin/admin.php?page=admin_2020_dashboard";
	}

  public function deregister_default(){
    wp_deregister_style('login');
    wp_deregister_style('buttons');
    wp_deregister_style('wp-admin');
  }
  ///LOAD STYLES TO LOGIN PAGE
  public function ma_admin_login_style() {

    wp_register_style('uikitcss', 'https://cdn.jsdelivr.net/npm/uikit@3.4.2/dist/css/uikit.min.css', false, $this->version);
    wp_enqueue_style('uikitcss');
    wp_enqueue_script('uikit', 'https://cdn.jsdelivr.net/npm/uikit@3.4.2/dist/js/uikit.min.js', array(), $this->version);
    wp_enqueue_script('uikiticons', 'https://cdn.jsdelivr.net/npm/uikit@3.4.2/dist/js/uikit-icons.min.js', array(), $this->version);
    wp_enqueue_style('custom-google-fonts', 'https://fonts.googleapis.com/css2?family=Sen:wght@400;700&display=swap', false);

    wp_register_style('ma-admin-login-css', plugin_dir_url(__DIR__) . 'assets/css/ma-admin-common.min.css', false, '1.0.0');
    wp_enqueue_style('ma-admin-login-css');

  }

  ///LOAD LOGO TO LOGIN PAGE
  public function ma_admin_login_logo() {
      $options = get_option('admin2020_settings');
      $logo = $options['admin2020_image_field_0'];
      if (!$logo) {
          $logo = esc_url(plugins_url('/assets/img/LOGO-BLUE.png', __DIR__));
      }
      echo '<style type="text/css"> h1 a {  background-image:url(' . $logo . ')  !important; } </style>';
  }



}
