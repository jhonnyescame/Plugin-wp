<?php
class Admin_2020_Plugin_Options{

	/// BUILD ADMIN 2020 SETTINGS PAGE
	public function run(){

		if (is_network_admin()){
			add_action( 'network_admin_menu', array($this,'admin2020_add_network_admin_menu') );
		}
		add_action( 'admin_menu', array($this,'admin2020_add_admin_menu') );
		add_action( 'admin_init',  array($this,'admin2020_settings_init') );

	}


	public function admin2020_add_admin_menu(  ) {

		add_options_page( 'Admin 2020', 'Admin 2020', 'manage_options', 'admin_2020', array($this,'admin2020_options_page') );

	}

	public function admin2020_add_network_admin_menu(  ) {

		add_menu_page( 'Admin 2020', 'Admin 2020', 'manage_options', 'admin_2020', array($this,'admin2020_options_page'),"admin2020-network-page"  );

	}


	public function admin2020_settings_init(  ) {

		register_setting( 'pluginPage', 'admin2020_settings' );

		add_settings_section(
			'admin2020_pluginPage_section',
			__( 'Customise Admin 2020 theme', 'admin2020' ),
			array($this,'admin2020_settings_section_callback'),
			'pluginPage'
		);

		add_settings_field(
			'admin2020_pluginPage_licence_key',
			__( 'Product Licence Key:', 'admin2020' ),
			array($this,'admin2020_licence_key_render'),
			'pluginPage',
			'admin2020_pluginPage_section'
		);

	  add_settings_field(
			'admin2020_image_field_0',
			__( 'Admin Logo', 'admin2020' ),
			array($this,'admin2020_image_field_0_render'),
			'pluginPage',
			'admin2020_pluginPage_section'
		);



		add_settings_field(
			'admin2020_disablestyles_field_2',
			__( 'Disabled Admin 2020 styles on plugin pages?', 'admin2020' ),
			array($this,'admin2020_disablestyles_field_2_render'),
			'pluginPage',
			'admin2020_pluginPage_section'
		);

	  add_settings_field(
	    'admin2020_loadfrontend_field_2',
	    __( 'Load Admin Menu style on front end?', 'admin2020' ),
	    array($this,'admin2020_loadfrontend_field_2_render'),
	    'pluginPage',
	    'admin2020_pluginPage_section'
	  );

		add_settings_field(
			'admin2020_admin2020_loader',
			__( 'Disable loading bar in admin bar?', 'admin2020' ),
			array($this,'admin2020_admin2020_loader_render'),
			'pluginPage',
			'admin2020_pluginPage_section'
		);

		add_settings_field(
			'admin2020_disable_overview',
			__( 'Disable overview page?', 'admin2020' ),
			array($this,'admin2020_disable_overview_render'),
			'pluginPage',
			'admin2020_pluginPage_section'
		);

		add_settings_field(
			'admin2020_overiew_homepage',
			__( 'Set overview page as Admin homepage?', 'admin2020' ),
			array($this,'admin2020_overiew_homepage_render'),
			'pluginPage',
			'admin2020_pluginPage_section'
		);

		add_settings_field(
			'admin2020_overiew_media_gallery',
			__( 'Use default wordpress media gallery?', 'admin2020' ),
			array($this,'admin2020_overiew_media_gallery_render'),
			'pluginPage',
			'admin2020_pluginPage_section'
		);

		add_settings_field(
			'admin2020_overiew_primary_color',
			__( 'Change primary link color', 'admin2020' ),
			array($this,'admin2020_overiew_primary_color_render'),
			'pluginPage',
			'admin2020_pluginPage_section'
		);


		add_settings_section(
			'admin2020_pluginPage_section_menu',
			__( 'User Menus', 'admin2020' ),
			array($this,'admin2020_settings_section_menu_callback'),
			'pluginPage'
		);

		add_settings_field(
			'admin2020_usermenu_fields',
			__( '', 'admin2020' ),
			array($this,'admin2020_usermenu_fields_render'),
			'pluginPage',
			'admin2020_pluginPage_section_menu'
		);

		add_settings_section(
			'admin2020_pluginPage_section_google',
			__( 'Google Analytics', 'admin2020' ),
			array($this,'admin2020_settings_section_google_callback'),
			'pluginPage'
		);

		add_settings_field(
			'admin2020_admin2020_google_apikey',
			__( 'Google Analytics API Key:', 'admin2020' ),
			array($this,'admin2020_admin2020_google_apikey_render'),
			'pluginPage',
			'admin2020_pluginPage_section_google'
		);
		add_settings_field(
			'admin2020_admin2020_google_viewid',
			__( 'Google Analytics View ID:', 'admin2020' ),
			array($this,'admin2020_admin2020_google_viewid_render'),
			'pluginPage',
			'admin2020_pluginPage_section_google'
		);




	}



	public function admin2020_licence_key_render(  ) {

		$options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_pluginPage_licence_key'])){
			$value = $options['admin2020_pluginPage_licence_key'];
		} else {
			$value = "";
		}
		?>
		<input type='text' style="width:100%;margin-bottom:15px;" name='admin2020_settings[admin2020_pluginPage_licence_key]' placeholder="xxxx-xxxx-xxxx-xxxx" value="<?php echo $value?>">
		<?php

	}




	public function admin2020_image_field_0_render(  ) {

		$options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_image_field_0'])){
			$value = $options['admin2020_image_field_0'];
		} else {
			$value = "";
		}
		?>
		<div class="ma-admin-backend-logo-holder">
		<img src="<?php echo $options['admin2020_image_field_0']; ?>" class="ma-admin-backend-logo" >
		</div>
	  <input id="background_image" type="text" name="admin2020_settings[admin2020_image_field_0]" value="<?php echo $options['admin2020_image_field_0']; ?>" hidden/>
	  <input id="upload_image_button" type="button" class="button-primary" value="Insert Image" hidden />

		<?php

	}





	public function admin2020_disablestyles_field_2_render(  ) {

		$options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_disablestyles_field_2'])){
			$value = $options['admin2020_disablestyles_field_2'];
		} else {
			$value = 0;
		}
		?>
		<input type='checkbox' name='admin2020_settings[admin2020_disablestyles_field_2]' <?php checked( $value, 1 ); ?> value='1'>
	  <span uk-icon="info"></span>
	  <p uk-dropdown class="uk-text-meta uk-width-medium"><?php _e('If Admin 2020 is causing issues on other plugin option pages you can choose to disable Admin 2020 styles on these pages. This can help with visibility issues that may arrise.','admin2020') ?></P>
	  <?php

	}

	public function admin2020_loadfrontend_field_2_render(  ) {

		$options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_loadfrontend_field_2'])){
			$value = $options['admin2020_loadfrontend_field_2'];
		} else {
			$value = 0;
		}
		?>
		<input type='checkbox' name='admin2020_settings[admin2020_loadfrontend_field_2]' <?php checked( $value, 1 ); ?> value='1'>
	  <span uk-icon="info"></span>
	  <p uk-dropdown class="uk-text-meta uk-width-medium"><?php _e('Enabling this may cause issues with your current theme.','admin2020')?></P>
	  <?php

	}

	public function admin2020_admin2020_loader_render(  ) {

		$options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_admin2020_loader'])){
			$value = $options['admin2020_admin2020_loader'];
		} else {
			$value = 0;
		}
		?>
		<input type='checkbox' name='admin2020_settings[admin2020_admin2020_loader]' <?php checked( $value, 1 ); ?> value='1'>
		<?php

	}

	public function admin2020_disable_overview_render(  ) {

		$options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_disable_overview'])){
			$value = $options['admin2020_disable_overview'];
		} else {
			$value = 0;
		}
		?>
		<input type='checkbox' name='admin2020_settings[admin2020_disable_overview]' <?php checked( $value, 1 ); ?> value='1'>
		<?php

	}

	public function admin2020_overiew_homepage_render(  ) {

		$options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_overiew_homepage'])){
			$value = $options['admin2020_overiew_homepage'];
		} else {
			$value = 0;
		}
		?>
		<input type='checkbox' name='admin2020_settings[admin2020_overiew_homepage]' <?php checked( $value, 1 ); ?> value='1'>
		<?php

	}


	public function admin2020_overiew_media_gallery_render(  ) {

		$options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_overiew_media_gallery'])){
			$value = $options['admin2020_overiew_media_gallery'];
		} else {
			$value = 0;
		}
		?>
		<input type='checkbox' name='admin2020_settings[admin2020_overiew_media_gallery]' <?php checked( $value, 1 ); ?> value='1'>
		<?php

	}

	public function admin2020_overiew_primary_color_render(  ) {

		$options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_overiew_primary_color'])){
			$value = $options['admin2020_overiew_primary_color'];
		} else {
			$value = "";
		}
		?>
		<input type='text' class="colorpicker" name='admin2020_settings[admin2020_overiew_primary_color]' value="<?php echo $value; ?>" >
		<script>
		jQuery(document).ready(function($){
		    $('.colorpicker').wpColorPicker();
		});
		</script>
		<?php

	}


	public function admin2020_admin2020_google_apikey_render() {

		$options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_admin2020_google_apikey'])){
			$value = $options['admin2020_admin2020_google_apikey'];
		} else {
			$value = "";
		}
		?>
		<input type='text' style="width:100%;margin-bottom:15px;" name='admin2020_settings[admin2020_admin2020_google_apikey]' placeholder="API Key" value="<?php echo $value?>">
		<?php

	}

	public function admin2020_admin2020_google_viewid_render( ) {

		$options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_admin2020_google_viewid'])){
			$value = $options['admin2020_admin2020_google_viewid'];
		} else {
			$value = "";
		}
		?>
		<input type='text' style="width:100%" name='admin2020_settings[admin2020_admin2020_google_viewid]' placeholder="View ID" value="<?php echo $value?>">
		<?php

	}

	public function admin2020_usermenu_fields_render() {

		$options = get_option( 'admin2020_settings' );

		$roles = $this->get_editable_roles();

		?>
		<div class="uk-text-meta uk-width-1-1 uk-margin-bottom">Select the role you wish to modify and select the items you want to hide.</div>
		<div uk-grid class="uk-margin-top">
	    <div class="uk-width-1-3">
			<ul class="uk-tab-left" uk-tab="connect: #admin-2020-menu-switch; animation: uk-animation-fade"><?php
			foreach ($roles as $role){
				if($role['name'] != 'Administrator'){
				?>
				    <li><a href="#"><?php echo $role['name']?></a></li>
				<?php
				}
			}
			?></ul>
			</div><?php


			global $maAdminMenuArray, $maAdminSubMenuArray;

			?>

			<div class="uk-width-expand">
				<ul class="uk-switcher uk-margin" id="admin-2020-menu-switch"><?php
						foreach ($roles as $role){

						if($role['name'] == 'Administrator'){
							continue;
						}

						?>

						<li><!--SWITCHER TAB -->

								<?php
								foreach($maAdminMenuArray as $item){ //START OF TOP LEVEL LOOP

									if (!$item[0]){
										continue;
									}

									$link = $item[2];
									if(isset($maAdminSubMenuArray[$link])){
										$subitems = $maAdminSubMenuArray[$link];
										$classe = 'uk-parent';
									} else {
										$subitems = array();
										$classe = '';
									}

									$rolelowercase = strtolower($role['name']);
									$parentitemname = strip_tags(strtolower($item[5]));

									if (isset($options['admin2020_menu_'.$rolelowercase.'_'.$parentitemname])){
										$value = $options['admin2020_menu_'.$rolelowercase.'_'.$parentitemname];
									} else {
										$value = 0;
									}

									$optionstring = 'admin2020_settings[admin2020_menu_'.$rolelowercase.'_'.$parentitemname.']';

									?>
									<ul class="uk-nav-default uk-nav-parent-icon" uk-nav="multiple: true"><!--MENU NAV -->
											<li class="uk-parent">
												<input name="<?php echo $optionstring ?>" class="ma-admin-menu-checkbox" type="checkbox" <?php checked( $value, 1 ); ?> value="1">
												<a href="#"><?php echo $item[0]?></a>

												<!--SUBNAV -->
												<ul class="uk-nav-sub admin-2020-settings-sub">

														<?php
														foreach($subitems as $sub){ //START OF SUB LEVEL LOOP

															$rolelowercase = strtolower($role['name']);
															$itemname = strip_tags(strtolower($sub[0]));
															$itemname = str_replace(" ","_",$itemname);

															if (isset($options['admin2020_submenu_'.$rolelowercase.'_'.$parentitemname.$itemname])){
																$value = $options['admin2020_submenu_'.$rolelowercase.'_'.$parentitemname.$itemname];
															} else {
																$value = 0;
															}

															$optionstring = 'admin2020_settings[admin2020_submenu_'.$rolelowercase.'_'.$parentitemname.$itemname.']';

														?>

														<li>
															<input name="<?php echo $optionstring ?>" class="ma-admin-menu-checkbox" type="checkbox" <?php checked( $value, 1 ); ?> value="1">
															<a href="#"><?php echo $sub[0]?></a>
														</li>

														<?php
													} //END OF SUB LEVEL LOOP ?>

												</ul>	<!--END OF SUBNAV -->


											</li>
									</ul><!--END OF MENU NAV -->

									<?php
									} ?> <!--END OF TOP LEVEL LOOP -->

						</li><!--END OF SWITCHER TAB -->

						<?php
						}?>

				</ul>
			</div>
		</div><?php

	}



	public function admin2020_settings_section_callback() {

		ob_start();?>

		<p class="uk-text-small uk-position-bottom uk-padding-large ma-admin-proudly-meta">
			<?php _e('Admin 2020 is proudly built with ','admin2020')?><a class="uk-link" href="https://getuikit.com/" target="_blank">UiKit</a>
		</p>

		<?php
		$content = ob_get_clean();

		echo __( 'Here you can change the admin logo and choose whether the admin theme loads on all pages. '.$content, 'admin2020' );

	}

	public function admin2020_settings_section_menu_callback() {



		echo __( 'Here you can change what areas of wordpress your users can access', 'admin2020' );

	}

	public function admin2020_settings_section_google_callback() {



		echo __( 'Here you can add your google details for dashboard reports', 'admin2020' );
		?>
		<p>For instructions of how to get the below details, please see <a href="https://admintwentytwenty.com/blog/activating-google-analytics-in-admin-2020" target="_blank" class="uk-link">here</a></p>
		<?php

	}


	public function admin2020_options_page(  ) {

			if (is_network_admin()){
				$action = admin_url().'options.php';
			} else {
				$action = 'options.php';
			}
			?>

			<form action='<?php echo $action ?>' method='post'>

				<h2>Admin 2020</h2>

				<?php
				settings_fields( 'pluginPage' );
				do_settings_sections( 'pluginPage' );
				submit_button();
				?>

			</form>
			<?php

	}

	public function get_editable_roles() {
	    global $wp_roles;

	    $all_roles = $wp_roles->roles;
	    $editable_roles = apply_filters('editable_roles', $all_roles);

	    return $editable_roles;
	}

}
