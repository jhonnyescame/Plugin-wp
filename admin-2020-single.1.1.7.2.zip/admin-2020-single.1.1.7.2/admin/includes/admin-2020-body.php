<?php
class Admin_2020_Body{

  public function run(){

    add_filter('admin_body_class', array($this, 'ma_admin_body_class'));

  }

  //OUTPUT BODY CLASSES
  public function ma_admin_body_class($classes) {

      $userid = get_current_user_id();
      $current = get_user_meta($userid, 'darkmode', true);
      $switch = get_user_meta($userid, 'ma-admin-switch', true);

      global $darkmode;
      $darkmode = $current;
      $bodyclass = '';

      if ($current === 'true') {
          $bodyclass = " uk-light ma-admin-dark ";
      }
      if ($switch === 'true') {
          $bodyclass = $bodyclass . " ma-admin-menu-shrink ";
      }
      return $bodyclass;
  }

}
