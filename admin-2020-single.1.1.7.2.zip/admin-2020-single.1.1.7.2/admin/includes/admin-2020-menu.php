<?php

class Admin_2020_Menu{

  public function build(){

    add_filter('parent_file', array( $this, 'admin_2020_rebbuild_menu'),999);
    add_action('adminmenu', array( $this, 'admin_2020_adminmenu' ));

  }





  public function admin_2020_rebbuild_menu() {

  		/// GET AND SET REQUIRED GLOBAL VARIABLES
      global $menu, $submenu, $pagenow, $maadminmenu, $wp, $maAdminMenuArray, $maAdminSubMenuArray;
  		$newmenu = array();
      $this->old_menu = $menu;
      $this->old_submenu = $submenu;

  		// GET CURRENT SCREEN
      $screen = get_current_screen();
      $screenid = $screen->parent_file;
      $maAdminMenuArray = $menu;
      $maAdminSubMenuArray = $submenu;

  		/// LIST OF AVAILABLE MENU ICONS
      $icons = array('dashicons-dashboard' => 'grid',
      'dashicons-admin-post' => 'file-text',
      'dashicons-admin2020-media' => 'image',
      'dashicons-admin-media' => 'image',
      'dashicons-admin-page' => 'album',
      'dashicons-admin-comments' => 'comment',
      'dashicons-admin-appearance' => 'paint-bucket',
      'dashicons-admin-plugins' => 'bolt',
      'dashicons-admin-users' => 'users',
      'dashicons-admin-tools' => 'cog',
      'dashicons-admin2020-grid' => 'thumbnails',
      'dashicons-admin-settings' => 'settings');
  		///GET ADMIN LOGO
      $logo = $this->ma_admin_get_logo();

  		/// START OUTPUT BUFFERING
      ob_start();
  ?>
    <div class="uk-padding ma-admin-menu-wrap ">
      <ul class="uk-nav-default uk-nav-parent-icon ma-admin-main-menu" uk-nav id="ma-admin-menu-list">

    		<!-- ADD MENU SEARCH TO THE TOP OF MENU -->

    		<li id="ma-admin-searchtab">
    			<div class="uk-margin-small">
    					<div class="uk-inline">
    							<span class="uk-form-icon" uk-icon="icon: search" ></span>
    							<input class="ma-admin-shrink uk-input ma-menu-search" type="search" placeholder="<?php _e('Search Menu...','admin2020')?>" id="ma-admin-menu-search">
    					</div>
    			</div>
    		</li>

    	<?php
    		//START LOOP THROUGH GLOBAL MENU ITEMS
        $options = get_option( 'admin2020_settings' );
        $user = wp_get_current_user();
        $userroles = $user->roles;
        $absolutepath = ABSPATH . '/wp-admin'."/";
        $files = array_diff(scandir($absolutepath), array('.', '..'));

        if (is_multisite()){
          $pathtonetwork = ABSPATH . '/wp-admin'."/network/";
          $networkfiles = array_diff(scandir($pathtonetwork), array('.', '..'));
          $files = array_merge($files,$networkfiles);
        }

        foreach ($menu as $item) {





            $hidden = 'false';
            $title = $item[0];

            if ($title) {
              foreach ($userroles as $role){

                $lcrole = strtolower($role);
                $lcparentname = strip_tags(strtolower($item[5]));
                $lcparentname = str_replace(" ","_",$lcparentname);

                if (isset($options['admin2020_menu_'.$lcrole.'_'.$lcparentname])){
                  if ($options['admin2020_menu_'.$lcrole.'_'.$lcparentname] == '1'){
                    $hidden = 'true';
                    break;
                  }
                }
              }
            }

            if ($hidden == 'true'){
              continue;
            }

            if (isset($options['admin2020_overiew_media_gallery'])){
            } else {
              if (isset($item[6])){
                if ($item[6] == 'dashicons-admin-media'){
                  continue;
                }
              }
            }




            $link = $item[2];
            if(isset($submenu[$link])){
              $subitems = $submenu[$link];
            } else {
              $subitems = array();
            }

    				/// CHECK IF DIVIDER / PARENT / SINGLE
            if (!$title) {
                ?>
                <li class="uk-nav-divider"></li>
                <?php
                continue;
            } else {
                $theclass = 'uk-parent wp-has-submenu';
                if (count($subitems) < 1) {
                    $theclass = '';
                }
            }

    				// SET MENU ICON
            $theicon = '';
            $wpicon = $item[6];

            if(isset($icons[$wpicon])){
              $theicon = $icons[$wpicon];
              $icons[$wpicon] = "";
            }

            if ($theicon) {
                $theicon = '<span class="uk-margin-right ma-admin-option-icon" uk-icon="icon: ' . $theicon . '"></span>';
            }
            if (!$theicon && $title) {
                if (strpos($item[6], 'http') !== false) {
                    $theicon = '<img class="uk-image uk-margin-right ma-admin-menu-icon ma-admin-option-icon" src="' . $item[6] . '">';
                } else {
                    $theicon = '<div class="wp-menu-image dashicons-before uk-margin-right ma-admin-option-icon '.$item[6].'"></div>';
                }
            }


    				///REPLACE COMMENT COUNT CLASS
            $title = str_replace('pending-count', 'uk-badge uk-align-right uk-text-center uk-margin-remove', $title);


    				// GET CURRENT URL QUERY TO FIND ACTIVE PAGE
            $currentquery = $_SERVER['QUERY_STRING'];
            if ($currentquery) {
                $currentquery = '?' . $currentquery;
            }
            $wholestring = $pagenow . $currentquery;
            $visibility = 'hidden';
            $open = 'wp-not-current-submenu';

    				/// SET MENU LINKS
            if ($title && count($subitems) > 0) {


                foreach ($subitems as $sub) {
                    if (strpos($sub[2], '.php') !== false) {
                        $link = $sub[2];

                        $querypieces = explode("?", $link);
                        $temp = $querypieces[0];

                        if( !in_array( $temp ,$files )){
                            $link = 'admin.php?page=' . $sub[2];
                        }
                    } else {
                        $link = 'admin.php?page=' . $sub[2];
                    }
                    if ($wholestring == $link && $theclass != 'uk-nav-divider') {
                        $open = 'uk-active uk-open';
                        $visibility = '';
                        break;
                    }
                }
            }
            $nosub = '#';
            if ($theclass === "") {
                $nosub = $item[2];
                if (strpos($nosub, '.php') !== false) {
                } else {
                    $nosub = 'admin.php?page='.$nosub;
                }
            }
            if (count($subitems) === 0 && $nosub === $wholestring) {
                $open = 'uk-active';
            }

    				/// ADJUST FOR LEGACY LINKS
            if(array_key_exists(5,$item)){
              $itemclasses = $item[5];
            } else {
              $itemclasses = '';
            }
            $correctlinks = str_replace("/", "-", $itemclasses);
            $correctlinks = str_replace("=", "-", $correctlinks);
            $correctlinks = str_replace("&", "-", $correctlinks);



            ?>


    					<!-- BUILD PARENT LI -->
    	        <li class="<?php echo $theclass . ' ' . $open . ' ' . $item[4] ?>" id="<?php echo $correctlinks ?>">
    	            <a href="<?php echo $nosub ?>" class="<?php echo $item[4] ?> ma-admin-shrink-viewer">
    		            <?php if ($theicon) {
    				            echo $theicon;
    				        }
                    ?>

    		            <span class="ma-admin-shrink"><?php echo $title; ?></span>
    		        </a>

    		        <?php


    				///BUILD SUB MENU IF EXISTS
            if (count($subitems) > 0) {
    ?>

    	            <ul class="uk-nav-sub uk-margin-bottom wp-submenu wp-submenu-wrap" <?php echo $visibility ?>>



    		        <?php
                $count = 0;
                foreach ($subitems as $sub) {


                    $hidden = 'false';
                    $title = $item[0];

                    if ($title) {
                      foreach ($userroles as $role){

                        $lcrole = strtolower($role);
                        $itemname = strip_tags(strtolower($sub[0]));
                        $itemname = str_replace(" ","_",$itemname);

                        if (isset($options['admin2020_submenu_'.$lcrole.'_'.$lcparentname.$itemname])){
                          if ($options['admin2020_submenu_'.$lcrole.'_'.$lcparentname.$itemname] == '1'){
                            $hidden = 'true';
                            break;
                          }
                        }
                      }
                    }
                    //echo $hidden;

                    if ($hidden == 'true'){
                      continue;
                    }


    								/// BUILD LINKS AND CLASSES
                    $firstitem = '';
                    if ($count == 0) {
                        $firstitem = 'wp-first-item';
                    }
                    $count = $count + 1;
                    if ($sub[0] == 'Background' ) {
                        continue;///HIDE TOP
                    }
                    $active = '';
                    if ($wholestring == $sub[2]) {
                        $active = "uk-active current";
                    }
                    if (strpos($sub[2], 'admin.php') !== false) {
                        $link = $sub[2];
                    } else if (strpos($sub[2], '.php') !== false) {
                        $link = $sub[2];
                        if (strpos($sub[2], '/') !== false) {
                            $pieces = explode("/", $sub[2]);
                            if (strpos($pieces[0], '.php') !== true || !file_exists(get_admin_url().$sub[2])) {
                                $link = 'admin.php?page=' . $sub[2];
                            }
                        }

                        $querypieces = explode("?", $link);
                        $temp = $querypieces[0];

                        if( !in_array( $temp ,$files )){
                            $link = 'admin.php?page=' . $sub[2];
                        }

                    }  else {
                        $link = 'admin.php?page=' . $sub[2];
                    }
    								?>


    							<!-- SUBMENU ITEMS -->
    						 <li class="<?php echo $active . ' ' . $firstitem ?>">

    						 	<a href="<?php echo $link ?>"  class="<?php echo $firstitem ?>"><?php echo $sub[0] ?></a>

    						 </li>

    						 <?php
    					  } /// END OF SUBBMENU LOOP
    						?>

    	            </ul>

    	            <?php
            } /// END OF SUBBMENU COUNT IF?>

    	        </li>


    	    <?php
        }/// END OF MAIN MENU LOOP
    ?>

    		  <!-- ADD MENU SHRINK ICONS -->
          <li class="uk-position-bottom uk-padding ma-admin-shrink-wrap">
      		    <a href="#" uk-icon="icon:shrink" class="uk-align-left uk-margin-remove ma-admin-shrinker uk-visible@m"></a>
      		    <a href="#" uk-icon="icon:expand" class="ma-admin-expander uk-visible@m"></a>
      	  </li>

        </ul>
      </div>
  		<!-- END OF MENU -->



      <?php
      $menu = array();
      $submenu = array();
      $maadminmenu = ob_get_clean();
  }

  /// OUTPUT MAIN MENU
  public function admin_2020_adminmenu() {
      global $maadminmenu,$menu,$submenu;
      echo $maadminmenu;
      $menu = $this->old_menu;
      $submenu = $this->old_submenu;
  }

  public function ma_admin_get_logo(){
    $options = get_option('admin2020_settings');
    if (isset($options['admin2020_image_field_0'])){
      $logo = $options['admin2020_image_field_0'];
    } else {
      $logo = esc_url(plugins_url('/assets/img/LOGO-BLUE.png', __DIR__));
    }
    if (!$logo) {
        $logo = esc_url(plugins_url('/assets/img/LOGO-BLUE.png', __DIR__));
    }
    return $logo;
  }




}
