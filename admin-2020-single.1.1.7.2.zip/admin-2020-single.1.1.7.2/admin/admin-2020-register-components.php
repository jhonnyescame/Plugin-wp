<?php
class Admin_2020_Register_Components {

  private $version;

  public function __construct( $theversion, $productid ) {

    $this->version = $theversion;
    $this->productid = $productid;

  }

  public function load(){
    $options = get_option( 'admin2020_settings' );
		$value = $options['admin2020_pluginPage_licence_key'];
    $this->run_validation($value);
  }

  public function run_validation($k){

    if(!get_transient( 'admin2020_components')){


      $productid = $this->productid;

      $ch = curl_init();
      $data = "key=".$k."&increment_usage_count=true";
      $data = '{"key":"'.$k.'","increment_usage_count":true}';
      //echo $data;

      curl_setopt($ch, CURLOPT_URL,"https://api.selz.com/products/".$productid."/licenses/verify");
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "accept: application/json",
        "content-type: application/json",
      ));

      $server_output = curl_exec($ch);

      curl_close ($ch);

      $response = json_decode($server_output);
      if(isset($response->is_active)){
        if($response->is_active == true){
          set_transient( 'admin2020_components', true, 24 * HOUR_IN_SECONDS );
          return;
        } else {
          $settingsurl = get_admin_url().'admin.php?page=admin_2020';
          $this->new_notice("Please enter a valid product key for Admin 2020 <a href='".$settingsurl."'>Here</a>");
        }
      } else {
        $settingsurl = get_admin_url().'admin.php?page=admin_2020';
        $this->new_notice("Please enter a valid product key for Admin 2020 <a href='".$settingsurl."'>Here</a>");
      }

    } else {
      return;
    }

  }

  public function new_notice($message){

    $this->message = $message;

    add_action('admin_notices', function($message){
      echo '<div class="notice notice-warning" style="display: block !important;visibility: visible !important;"><p>';
      echo $this->message;
      echo  '</p></div>';
    });

  }

}
