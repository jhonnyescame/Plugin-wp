<?php

class Admin_2020_Private_Actions {

  private $version;

  public function __construct( $theversion ) {

		$this->version = $theversion;

	}

  public function run() {

    $this->load_styles();
    $this->load_admin_menu();
    $this->load_admin_bar();
    $this->edit_wp_tables();
    $this->register_ajax_functions();
    $this->add_plugin_options();
    $this->add_body_classes();
    $this->build_dashboard();
    $this->build_media();

  }


  public function load_styles(){

    $admin_2020_styles = new Admin_2020_Styles($this->version);
    $admin_2020_styles->load();

  }

  public function load_admin_menu(){

    $admin_2020_menu = new Admin_2020_Menu();
    $admin_2020_menu->build();

  }

  public function load_admin_bar(){

    $admin_2020_Admin_Bar = new Admin_2020_Admin_Bar();
    $admin_2020_Admin_Bar->build();

  }

  public function edit_wp_tables(){

    $admin_2020_styles = new Admin_2020_Table_Actions();
    $admin_2020_styles->run();

  }

  public function register_ajax_functions(){

    $admin_2020_ajax = new Admin_2020_Ajax();
    $admin_2020_ajax->register();

  }

  public function add_plugin_options(){

    $admin_2020_plugin_options = new Admin_2020_Plugin_Options();
    $admin_2020_plugin_options->run();

  }

  public function add_body_classes(){

    $admin_2020_body = new Admin_2020_Body();
    $admin_2020_body->run();

  }

  public function build_dashboard(){

    $options = get_option( 'admin2020_settings' );
		if (isset($options['admin2020_disable_overview'])){
			//OVERVIEW DISABLED
		} else {
      $admin_2020_dashbboard = new Admin_2020_Dashboard($this->version);
      $admin_2020_dashbboard->run();
		}

  }

  public function build_media(){

    $options = get_option( 'admin2020_settings' );
    if (isset($options['admin2020_overiew_media_gallery'])){
      //MEDIA DISABBLED DISABLED
    } else {
      $admin_2020_media = new Admin_2020_Media($this->version);
      $admin_2020_media->run();
    }

  }


}
